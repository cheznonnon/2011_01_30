// OrangeCat
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




#define N_ORANGECAT_EVENT_ZERO       0
#define N_ORANGECAT_EVENT_INIT       1
#define N_ORANGECAT_EVENT_REDRAW     2
#define N_ORANGECAT_EVENT_VIEWCHANGE 3
#define N_ORANGECAT_EVENT_TRANSITION 4
#define N_ORANGECAT_EVENT_BTN_PRESS  5




#define n_oc_event_is_busy() ( oc.event != N_ORANGECAT_EVENT_ZERO )

void
n_oc_event_zero( void )
{

	oc.event            = N_ORANGECAT_EVENT_ZERO;
	oc.transition_event = N_ORANGECAT_EVENT_ZERO;


	return;
}

void
n_oc_event_init( void )
{

	if ( oc.transition_onoff )
	{
		if ( oc.transition_is_running )
		{
//n_posix_debug_literal( " true : %d ", oc.event );
			oc.transition_is_running = false;
		}

		oc.event            = N_ORANGECAT_EVENT_TRANSITION;
		oc.transition_event = N_ORANGECAT_EVENT_INIT;
	} else {
		oc.event = N_ORANGECAT_EVENT_INIT;
	}


	return;
}

void
n_oc_event_redraw( void )
{

	if ( oc.transition_onoff )
	{
		oc.event            = N_ORANGECAT_EVENT_TRANSITION;
		oc.transition_event = N_ORANGECAT_EVENT_REDRAW;
	} else {
		oc.event = N_ORANGECAT_EVENT_REDRAW;
	}


	return;
}

void
n_oc_event_redraw_fast( void )
{

	oc.event = N_ORANGECAT_EVENT_REDRAW;


	return;
}

void
n_oc_event_viewchange( void )
{

	oc.event = N_ORANGECAT_EVENT_VIEWCHANGE;


	return;
}

void
n_oc_event_transition( void )
{

	oc.event = N_ORANGECAT_EVENT_TRANSITION;


	return;
}

void
n_oc_event_btn_press( void )
{

	oc.event = N_ORANGECAT_EVENT_BTN_PRESS;


	return;
}

void
n_oc_event_itemsync( void )
{

	//oc.event = N_ORANGECAT_EVENT_INIT;


	extern void n_oc_item_sync_forcesync( n_oc_item* );
	n_oc_item_sync_forcesync( &item );

	n_oc_event_zero();


	return;
}


