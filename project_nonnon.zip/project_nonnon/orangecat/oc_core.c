// OrangeCat
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




#define n_oc_drive_is_accessible( name ) ( 0 != n_sysinfo_drive_info( name ) )

bool
n_oc_bool_toggle( bool b )
{

	if ( b ) { b = false; } else { b = true; }


	return b;
}

bool
n_oc_is_draggable( void )
{

	int threshold_sx = 0;
	int threshold_sy = 0;
	n_win_mouse_threshold( game.hwnd, &threshold_sx, &threshold_sy );


	s32  x = oc.cursor_px - threshold_sx;
	s32  y = oc.cursor_py - threshold_sy;
	s32 sx = threshold_sx * 2;
	s32 sy = threshold_sy * 2;


	return ( false == n_win_is_hovered_offset( game.hwnd, x,y,sx,sy ) );
}

double
n_oc_orangecat2scroll( double pos, double oc_max )
{
	return ( pos / oc_max ) * oc.scrollbar.pixel_max;
}

double
n_oc_scroll2orangecat( double pos, double oc_max )
{
	return ( pos / oc.scrollbar.pixel_max ) * oc_max;
}

void
n_oc_key_operation_onoff( bool onoff )
{

	if ( n_win_is_input( VK_CONTROL ) ) { return; }
	if ( n_win_is_input( VK_SHIFT   ) ) { return; }


	oc.view_is_key_operation = onoff;

	if ( oc.view_is_key_operation )
	{
		oc_color.item_focus = oc_color.item_key_o;//oc_color.item_key_i;
	} else {
		oc_color.item_focus = oc_color.item_key_o;
	}


	return;
}

void
n_oc_frame( n_bmp *bmp, s32 x, s32 y, s32 sx, s32 sy, s32 m, s32 round, u32 fg, u32 bg )
{

	if ( oc.is_round )
	{
		n_bmp_roundrect_ratio( bmp, x,y,sx,sy, fg, round );
	} else {
		n_bmp_box( bmp, x,y,sx,sy, fg );
	}

	if ( fg == bg ) { return; }

	 x += m;
	 y += m;
	sx -= m * 2;
	sy -= m * 2;

	if ( oc.is_round )
	{
		n_bmp_roundrect_ratio_coeff( bmp, x,y,sx,sy, bg, round, 1.0 );
	} else {
		n_bmp_box( bmp, x,y,sx,sy, bg );
	}


	return;
}

#define N_OC_LINEFRAME_UNIT ( oc.unit_scal )

void
n_oc_lineframe( n_bmp *bmp, s32 x, s32 y, s32 sx, s32 sy, u32 fg )
{

	if ( n_bmp_error( bmp ) ) { return; }


	if ( sx <= ( 2 * oc.unit_scal ) ) { return; }
	if ( sy <= ( 2 * oc.unit_scal ) ) { return; }


	const s32 unit = N_OC_LINEFRAME_UNIT;
	const s32 u    = unit * 1;
	const s32 uu   = unit * 2;

	n_bmp b; n_bmp_zero( &b ); n_bmp_1st_fast( &b, sx, sy ); n_bmp_flush( &b, fg );

	n_bmp_box( &b, u, u, sx - uu, sy - uu, n_bmp_white_invisible );

	n_bmp_transcopy( &b, bmp, 0,0,sx,sy, x,y );


	n_bmp_free( &b );


	return;
}

void
n_oc_splashscreen( void )
{

	n_gdi gdi; n_gdi_zero( &gdi );


	gdi.sx                 = 0;
	gdi.sy                 = 0;
	gdi.style              = N_GDI_DEFAULT;
	gdi.layout             = N_GDI_LAYOUT_VERTICAL;
	gdi.align              = N_GDI_ALIGN_CENTER;

	gdi.base_color_bg      = game.color;
	gdi.base_color_fg      = game.color;
	gdi.base_style         = N_GDI_BASE_SOLID;
	gdi.base_unit          = 0;

	gdi.frame_style        = N_GDI_FRAME_NOFRAME;

	gdi.icon               = oc.exec;
	gdi.icon_index         = N_APPS_ICON_OFFSET_ORANGECAT;
	gdi.icon_style         = oc.icon_resource;
	gdi.icon_fxsize1       = 0;
	gdi.icon_fxsize2       = 0;

	gdi.text               = N_ORANGECAT_APPNAME;
	gdi.text_font          = n_oc_font_name;
	gdi.text_size          = n_oc_font_size;
	gdi.text_color_main    = oc_color.item_text;
	gdi.text_color_contour = oc_color.item_shadow;
	gdi.text_style         = n_oc_font_smooth;
	gdi.text_fxsize1       = 0;
	gdi.text_fxsize2       = oc.view_text_fxsize;


	n_bmp bmp; n_bmp_zero( &bmp );


	n_gdi_bmp( &gdi, &bmp );


	s32 sx = gdi.sx;
	s32 sy = gdi.sy;
	s32 tx = ( game.sx - sx ) / 2;
	s32 ty = ( game.sy - sy ) / 2;

	//n_bmp_flush( &game.bmp, oc_color.info_bg_1 );
	n_bmp_transcopy( &bmp, &game.bmp, 0,0,sx,sy, tx,ty );

	n_bmp_free( &bmp );


	return;
}

bool
n_oc_is_desktop( void )
{

	// [!] : Win9x hasn't "FolderView" as a caption

	HWND hwnd          = oc.view_hwnd;
	HWND hwnd_toplevel = n_win_hwnd_toplevel( hwnd );


	n_posix_char str_toplevel_class[ N_WIN_CLASS_CCH ];
	n_posix_char str_toplevel_text [ N_WIN_CLASS_CCH ];

	n_win_class   ( hwnd_toplevel, str_toplevel_class );
	n_win_text_get( hwnd_toplevel, str_toplevel_text,  N_WIN_CLASS_CCH - 1 );

//n_game_hwndprintf_literal( "%s", str_toplevel_class, str_toplevel_text );

	if (
		( n_string_is_same_literal( "Progman",         str_toplevel_class ) )
		&&
		( n_string_is_same_literal( "Program Manager", str_toplevel_text  ) )
	)
	{
		return true;
	}


	n_posix_char str_class[ N_WIN_CLASS_CCH ];
	n_posix_char str_text [ N_WIN_CLASS_CCH ];

	n_win_class   ( hwnd, str_class );
	n_win_text_get( hwnd, str_text,  N_WIN_CLASS_CCH - 1 );

//n_game_hwndprintf_literal( "%s", str_class, str_text );

	if (
		(
			( n_string_is_same_literal( "WorkerW", str_toplevel_class ) )
			||
			( n_string_is_same_literal( "Progman", str_toplevel_class ) )
		)
		&&
		( n_string_is_same_literal( "SysListView32", str_class ) )
		&&
		( n_string_is_same_literal( "FolderView",    str_text  ) )
	)
	{
		return true;
	}


	return false;
}

bool
n_oc_is_anotherwindow( void )
{

//n_game_hwndprintf_literal( " %d ", oc.is_external_dnd );

	bool is_oc   = n_win_message_send( oc.view_hwnd, oc.msg_is_oc        , 0,0 );
	int  is_drag = n_win_message_send( oc.view_hwnd, oc.msg_drag_internal, 0,0 );

//n_game_hwndprintf_literal( " %d ", is_oc );
//n_game_hwndprintf_literal( " %d ", is_drag );

//n_game_hwndprintf_literal( " %d %d ", is_oc, is_drag );

	if (
		( game.hwnd != oc.view_hwnd )
		&&
		( oc.is_external_dnd )
		&&
		(
			( is_oc == false )
			||
			( is_drag == N_ORANGECAT_DRAG_UNKNOWN )
		)
	)
	{
//n_game_hwndprintf_literal( "  true : %d ", is_drag );
		return true;
	} else {
//n_game_hwndprintf_literal( " false : %d ", is_drag );
	}


	return false;
}

bool
n_oc_is_desktop_selection( void )
{

	if (
		( oc.is_external_dnd )
		&&
		( n_IDropTarget_is_running == false )
		&&
		( oc.view_drag_oc2oc == false )
	)
	{
		return true;
	}


	return false;
}

void
n_oc_reset_scroll( void )
{

	if ( oc.style == N_ORANGECAT_STYLE_CLASSIC )
	{
		oc.style_scrollbar = N_WIN_SCROLLBAR_STYLE_SOLID;
	} else
	if ( oc.style == N_ORANGECAT_STYLE_LUNA )
	{
		if ( n_sysinfo_version_xp() )
		{
			oc.style_scrollbar = N_WIN_SCROLLBAR_STYLE_VISUALSTYLE;
		} else {
			if ( oc.dwm_onoff == false )
			{
				oc.style_scrollbar = N_WIN_SCROLLBAR_STYLE_STRIPE_ROUND;
			} else {
				oc.style_scrollbar = N_WIN_SCROLLBAR_STYLE_STRIPE;
			}
		}
	} else
	if ( oc.style == N_ORANGECAT_STYLE_AERO )
	{
		if ( ( n_sysinfo_version_vista() )||( n_sysinfo_version_7() ) )
		{
			oc.style_scrollbar = N_WIN_SCROLLBAR_STYLE_VISUALSTYLE;
		} else {
			oc.style_scrollbar = N_WIN_SCROLLBAR_STYLE_STRIPE;
		}
	} else
	if ( oc.style == N_ORANGECAT_STYLE_8 )
	{
		if ( n_sysinfo_version_8_or_later() )
		{
			oc.style_scrollbar = N_WIN_SCROLLBAR_STYLE_VISUALSTYLE;
		} else {
			oc.style_scrollbar = N_WIN_SCROLLBAR_STYLE_SOLID;
		}
	} else
	if ( oc.style == N_ORANGECAT_STYLE_AQUA )
	{
		if ( oc.dwm_onoff == false )
		{
			oc.style_scrollbar = N_WIN_SCROLLBAR_STYLE_STRIPE_ROUND;
		} else {
			oc.style_scrollbar = N_WIN_SCROLLBAR_STYLE_STRIPE;
		}
	}// else

	if (
		( oc.style == N_ORANGECAT_STYLE_CLASSIC )
		||
		( oc.style == N_ORANGECAT_STYLE_8       )
	)
	{
		oc.stripe = 0;
	} else {
		oc.stripe = oc.unit_scrl;
	}

	if ( oc.dwm_onoff )
	{
		oc.scrollbar.option |=  N_WIN_SCROLLBAR_OPTION_DWM_ON;
	} else {
		oc.scrollbar.option &= ~N_WIN_SCROLLBAR_OPTION_DWM_ON;
	}

	oc.scrollbar.style = oc.style_scrollbar;
/*
	if ( oc.style == N_ORANGECAT_STYLE_AQUA )
	{
		n_win_scrollbar_on_settingchange_color_dwm_window = false;
	} else {
		n_win_scrollbar_on_settingchange_color_dwm_window =  true;
	}
*/

	if ( oc.transition_onoff == false )
	{
		n_win_scrollbar_refresh_redraw_area( &oc.scrollbar );
		n_win_scrollbar_on_settingchange( &oc.scrollbar, false, true );
	}


	item.is_blank = true;


	return;
}

void
n_oc_reset_round( void )
{

	oc.is_round = false;

	n_game_progressbar_no_round = false;

	if ( oc.style == N_ORANGECAT_STYLE_LUNA ) { oc.is_round = true; } else
	if ( oc.style == N_ORANGECAT_STYLE_AERO ) { oc.is_round = true; } else
	if ( oc.style == N_ORANGECAT_STYLE_AQUA ) { oc.is_round = true; }// else


	return;
}

void
n_oc_reset_stdsize( void )
{

	s32 m; n_win_stdsize( game.hwnd, &oc.unit, &oc.unit_icon, &m );

	oc.unit_path = oc.unit;
	oc.unit_icon = oc.unit_icon;
	oc.unit_scrl = n_win_scrollbar_stdsize( &oc.scrollbar );
	oc.unit_rect = 25;
	oc.unit__dpi = n_win_dpi( game.hwnd );
	oc.unit_scal = n_posix_max_s32( 1, oc.unit__dpi / 75 );

	n_game_progressbar_border = oc.unit_scal;

//n_posix_debug_literal( " %d ", oc.unit_scrl );

/*
	// [!] : debug for Style Changer

	static int i = 0;
	if ( i % 2 ) { oc.unit_icon = 48; } else { n_oc_font_size = 64; }
	i++;
*/

	return;
}

void
n_oc_reset_uxtheme( void )
{

	n_uxtheme_exit( &oc.uxtheme, game.hwnd );
	n_uxtheme_init( &oc.uxtheme, game.hwnd, L"BUTTON" );


	return;
}

void
n_oc_reset_dragselection_alpha( void )
{

	DWORD dw = 0;

	n_registry_read
	(
		HKEY_CURRENT_USER,
		n_posix_literal( "Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced" ),
		n_posix_literal( "ListviewAlphaSelect" ),
		&dw,
		sizeof( DWORD )
	);
//n_posix_debug_literal( "%d", dw );

	oc.dragselection_alpha_onoff = ( dw != 0 );


	return;
}

void
n_oc_reset( void )
{

	n_game_click_init( &oc.singleclick_l, VK_LBUTTON );
	n_game_click_init( &oc.singleclick_m, VK_MBUTTON );
	n_game_click_init( &oc.singleclick_r, VK_RBUTTON );

	n_game_click_init( &oc.doubleclick_l, VK_LBUTTON );
	n_game_click_init( &oc.doubleclick_m, VK_MBUTTON );
	n_game_click_init( &oc.doubleclick_r, VK_RBUTTON );

	n_game_click_init( &oc.singleclick_delete, VK_DELETE );
	n_game_click_init( &oc.singleclick_bspace, VK_BACK   );


	// [!] : before n_oc_ini_read()

	n_game_dwm_onoff();

	n_oc_reset_stdsize();
	n_oc_reset_uxtheme();


	n_oc_ini_read();


	// [!] : after n_oc_ini_read()

	n_oc_color_init();

	n_oc_reset_round();
	n_oc_reset_scroll();

	n_win_scrollbar_refresh_redraw_area( &oc.scrollbar );
	n_win_scrollbar_on_settingchange( &oc.scrollbar, false, true );


	n_thread_onoff();


	return;
}

void
n_oc_style_autoselect( void )
{

	n_oc_reset_uxtheme();

	if ( oc.uxtheme.onoff )
	{

		if ( n_sysinfo_version_8_or_later() )
		{
			oc.style = N_ORANGECAT_STYLE_8;
		} else
		if ( n_sysinfo_version_vista_or_later() )
		{
			oc.style = N_ORANGECAT_STYLE_AERO;
		} else {
			oc.style = N_ORANGECAT_STYLE_LUNA;
		}

	} else {

		oc.style = N_ORANGECAT_STYLE_CLASSIC;

	}


	oc.fade_onoff = n_win_fade_is_on();

	if ( oc.fade_onoff )
	{
		oc.transition_onoff = true;
		oc.transition_type  = N_GAME_TRANSITION_FADE;
	}


	return;
}

void
n_oc_reset_style( void )
{

	n_oc_reset_stdsize();


	if ( oc.style_auto )
	{
		n_oc_style_autoselect();
	} else {
		n_oc_reset_uxtheme();
	}


	n_oc_ini_dwm_onoff();


	// [!] : after n_oc_ini_dwm_onoff()

	n_oc_font_init( oc.font_smooth_auto, oc.font_smooth_onoff );


	n_oc_color_init();


	n_oc_reset_round();


	n_oc_path_init( &path );


	{

		extern void n_oc_item_gdi_set( n_oc_item* );
		n_oc_item_gdi_set( &item );

		extern void n_oc_item_view_set_unitsize( n_oc_item* );
		n_oc_item_view_set_unitsize( &item );

		int i = 0;
		while( 1 )
		{
			if ( i >= item.count ) { break; }

			if ( item.multifocus[ i ] )
			{
				n_bmp_fade_init( &item.fade[ i ], oc_color.item_focus );
			}

			i++;
		}


		if ( ( item.tooltip_hover != N_ORANGECAT_NOTHING )||( oc.view_is_key_operation ) )
		{
			if ( item.count > 0 )
			{
				n_oc_item_hover2tooltip_draw( &item, true );
			}
		}

	}


	n_oc_reset_scroll();

	// [!] : delayed : see N_ORANGECAT_EVENT_TRANSITION @ orangecat.c

	//n_win_scrollbar_refresh_redraw_area( &oc.scrollbar );
	//n_win_scrollbar_on_settingchange( &oc.scrollbar, false, true );


	n_oc_reset_dragselection_alpha();


	n_oc_event_redraw();


	return;
}

bool
n_oc_shellexecute( const n_posix_char *verb, const n_posix_char *exe, const n_posix_char *param, int sw )
{

	int ret = (int) ShellExecute( game.hwnd, verb, exe, param, NULL, sw );
//n_posix_debug_literal( "%d", ret );
	if ( ret < 32 ) { return true; }


	return false;
}

void
n_oc_navigate( const n_posix_char *name )
{
//return;

	// [!] : be careful : "name" == oc.back is possible


	if ( n_string_is_empty( name ) ) { return; }


	n_string_path_free( oc.navi );
	oc.navi = n_string_path_carboncopy( name );
//n_posix_debug_literal( " %s ", oc.navi );

	oc.view_navigate_onoff = true;

//n_posix_debug_literal( " %d ", oc.event );

	//oc.event = N_ORANGECAT_EVENT_INIT;
	n_oc_event_init();


	return;
}

void
n_oc_navigate_back( void )
{

	if ( oc.view_is_computer )
	{
		n_string_truncate( oc.head );
	} else {
		if ( oc.link != NULL )
		{
//n_posix_debug_literal( "%s", oc.link );
			n_string_path_free( oc.head );
			oc.head = n_string_path_carboncopy( oc.link );
		} else {
			n_string_path_free( oc.head );
			oc.head = n_string_path_carboncopy( oc.main );
		}
	}

	n_oc_navigate( oc.back );


	return;
}

void
n_oc_navigate_history( n_posix_char *name )
{

	if ( n_string_is_same( name, oc.main ) )
	{
		n_oc_item_scroll_restore( &item );
	} else
	if ( n_string_is_same( name, oc.back ) )
	{
		oc.view_scroll_restore = oc.view_scroll_back;
	} else {
		oc.view_scroll_restore = 0;
	}

	if (
		( false == n_string_is_same( oc.main,    name ) )
		&&
		( false == n_string_is_same( oc.main, oc.back ) )
		&&
		( false == n_string_is_same( oc.back,    name ) )
	)
	{
		n_string_path_free( oc.back );
		oc.back = n_string_path_carboncopy( oc.main );

		oc.view_scroll_back = n_oc_item_scroll2orangecat( &item, oc.scrollbar.pixel_pos );
	}


	return;
}

void
n_oc_newwindow( n_posix_char *name, bool link_onoff )
{

	if ( n_string_is_empty( name ) ) { return; }


	n_posix_char *str = N_STRING_EMPTY;


	if ( link_onoff )
	{

#ifdef NONNON_APPS

		str = n_string_path_cat
		(
			oc.exec                  , N_STRING_SPACE,
			N_APPS_OPTION_ORANGECAT  , N_STRING_SPACE,
			N_ORANGECAT_OPTION_NOLINK, N_STRING_SPACE,
			name                     , NULL
		);

#else  // #ifdef NONNON_APPS

		str = n_string_path_cat
		(
			oc.exec                  , N_STRING_SPACE,
			N_ORANGECAT_OPTION_NOLINK, N_STRING_SPACE,
			name                     , NULL
		);

#endif // #ifdef NONNON_APPS

	} else {

#ifdef NONNON_APPS

		str = n_string_path_cat
		(
			oc.exec                  , N_STRING_SPACE,
			N_APPS_OPTION_ORANGECAT  , N_STRING_SPACE,
			name                     , NULL
		);

#else  // #ifdef NONNON_APPS

		str = n_string_path_cat
		(
			oc.exec                  , N_STRING_SPACE,
			name                     , NULL
		);

#endif // #ifdef NONNON_APPS

	}
//n_game_hwndprintf_literal( "%s", str );


	n_posix_sleep( N_ORANGECAT_INTERVAL_BASE );
	n_win_exec( str, SW_NORMAL );


	n_string_path_free( str );


	return;
}

#define N_OC_LNK2PATH_CCH_MAX ( N_ISHELLLINK_LNK2PATH_CCH_PATH + 1 + N_ISHELLLINK_LNK2PATH_CCH_ARGS + 2 )

void
n_oc_lnk2path( const n_posix_char *lnk, n_posix_char *path, n_posix_char *args )
{

	n_posix_char *c = n_string_path_new( N_OC_LNK2PATH_CCH_MAX          ); n_string_zero( c, N_OC_LNK2PATH_CCH_MAX          );
	n_posix_char *p = n_string_path_new( N_ISHELLLINK_LNK2PATH_CCH_PATH ); n_string_zero( p, N_ISHELLLINK_LNK2PATH_CCH_PATH );
	n_posix_char *a = n_string_path_new( N_ISHELLLINK_LNK2PATH_CCH_ARGS ); n_string_zero( a, N_ISHELLLINK_LNK2PATH_CCH_ARGS );


	n_IShellLink_lnk2path( lnk, p, a, NULL, NULL );
	if ( n_string_is_empty( p ) )
	{

		n_string_copy( lnk, c );
		n_string_copy( lnk, p );

	} else {

		if ( n_string_is_empty( a ) )
		{
			n_string_copy( p, c );
		} else {
			n_posix_sprintf_literal( c, "%s %s", p, a );
		}

	}


	if ( path != NULL )
	{

		if ( args == NULL )
		{
			n_string_path_copy( c, path );
		} else {
			n_string_path_copy( p, path );
			n_string_path_copy( a, args );
		}

	}
//n_posix_debug_literal( "%s\n%s\n%s", c, p, a );


	n_string_path_free( c );
	n_string_path_free( p );
	n_string_path_free( a );


	return;
}

void
n_oc_dnd_cursor( void )
{

	// [!] : this module is used at OrangeCat to OrangeCat


	if ( oc.view_is_computer ) { return; }

//n_win_cursor_add( NULL, IDC_NO ); return;


	extern bool n_oc_path_hover_is_computer_global( n_oc_path* );


	bool is_oc        = n_win_message_send( oc.view_hwnd, oc.msg_is_oc,        0,0 );
	int  is_computer  = n_win_message_send( oc.view_hwnd, oc.msg_is_computer,  0,0 );
	bool is_droppable = n_win_message_send( oc.view_hwnd, oc.msg_is_droppable, 0,0 );


	bool find_onoff;
	if ( oc.view_hwnd == game.hwnd )
	{
		find_onoff = item.find_onoff;
	} else {
		find_onoff = ( false == n_win_message_send( oc.view_hwnd, oc.msg_find_onoff, 0,0 ) );
	}
//n_game_hwndprintf_literal( " %d ", find_onoff );


	if ( ( is_oc )&&( is_computer )&&( is_droppable == false ) )
	{
		n_win_cursor_add( NULL, IDC_NO );
	} else
	if ( n_oc_path_hover_is_computer_global( &path ) )
	{
//n_game_hwndprintf_literal( " n_oc_path_hover_is_computer_global() " );
		n_win_cursor_add( NULL, IDC_NO );
	} else
	if ( item.drag == N_ORANGECAT_DRAG_UNKNOWN )
	{
		if ( item.find_onoff )
		{
			n_win_cursor_add( NULL, IDC_NO );
		} else {
			n_win_cursor_add_literal( NULL, "Z_CURSOR_DND" );
		}
	} else
	if ( item.drag == N_ORANGECAT_DRAG_LBUTTON )
	{
		if ( ( item.find_onoff )&&( oc.view_hover == N_ORANGECAT_VIEW_HOVER_PATH ) )
		{
			n_win_cursor_add( NULL, IDC_NO );
		} else
		if ( ( is_droppable == false )&&( find_onoff == false ) )
		{
			n_win_cursor_add( NULL, IDC_NO );
		} else {
			n_win_cursor_add_literal( NULL, "Z_CURSOR_DND_MOVE" );
		}
	} else
	if ( item.drag == N_ORANGECAT_DRAG_MBUTTON )
	{
		if ( ( item.find_onoff )&&( oc.view_hover == N_ORANGECAT_VIEW_HOVER_PATH ) )
		{
			n_win_cursor_add( NULL, IDC_NO );
		} else
		if ( ( is_droppable == false )&&( find_onoff == false ) )
		{
			n_win_cursor_add( NULL, IDC_NO );
		} else {
			n_win_cursor_add_literal( NULL, "Z_CURSOR_DND_LINK" );
		}
	} else
	if ( item.drag == N_ORANGECAT_DRAG_RBUTTON )
	{
		if ( ( item.find_onoff )&&( oc.view_hover == N_ORANGECAT_VIEW_HOVER_PATH ) )
		{
			n_win_cursor_add( NULL, IDC_NO );
		} else
		if ( ( is_droppable == false )&&( find_onoff == false ) )
		{
			n_win_cursor_add( NULL, IDC_NO );
		} else {
			n_win_cursor_add_literal( NULL, "Z_CURSOR_DND_COPY" );
		}
	}


	return;
}

bool
n_oc_dnd_clone( const n_posix_char *f, const n_posix_char *t )
{

	n_win_cursor_add( NULL, IDC_WAIT );


	n_posix_char *tgt = n_string_path_carboncopy( t ); n_string_path_drivename_slash_del( tgt ); n_string_path_ext_del( tgt );
	n_posix_char *nam = n_string_path_name_new( f ); n_string_path_ext_del( nam );
	n_posix_char *tmp = n_string_path_tmpname_new( N_STRING_EMPTY );
	n_posix_char *ext = n_string_path_ext_get_new( f );
	n_posix_char *str = n_string_path_cat( tgt, N_POSIX_SLASH, nam, n_posix_literal( "_" ), tmp, ext, NULL );

//n_posix_debug_literal( "From:%s\nTo:%s\nTgt:%s\nNam:%s\nTmp:%s\nExt:%s\nStr:%s", f, t, tgt, nam, tmp, ext, str );

	n_posix_char *upp = n_string_path_upperfolder_new( f );

	if ( n_string_is_same( upp, tgt ) )
	{
		str = n_string_path_cat( tgt, N_POSIX_SLASH, nam, n_posix_literal( "_" ), tmp, ext, NULL );
	} else {
		str = n_string_path_cat( tgt, N_POSIX_SLASH, nam,                              ext, NULL );
	}

//n_posix_debug_literal( "%s\n%s", upp, tgt );

	n_string_path_free( upp );


	bool ret = false;


	n_dir f_d; n_dir_zero( &f_d ); n_dir_load_recursive( &f_d, f ); n_dir_sort( &f_d );
	n_dir t_d; n_dir_zero( &t_d );

	if ( n_filer_copy( f, str ) )
	{

		ret = true;

	} else {

		// [!] : integrity checker

		// [!] : don't use n_filer_is_same() : copy to the inner folder support

		n_dir_load_recursive( &t_d, str ); n_dir_sort( &t_d );

		size_t i = 0;
		while( 1 )
		{

			if ( i >= n_dir_all( &f_d ) ) { ret = true; break; }

			n_posix_char *f_name = n_string_path_make_new( n_dir_path( &f_d, i ), n_dir_name( &f_d, i ) );
			n_posix_char *t_name = n_string_path_make_new( n_dir_path( &t_d, i ), n_dir_name( &t_d, i ) );
//n_posix_debug_literal( "F:%s\nT:%s", f_name, t_name );

			if (
				( n_posix_stat_is_file( f_name ) )
				&&
				( n_posix_stat_is_file( t_name ) )
			)
			{
				ret = n_filer_is_same( f_name, t_name );
			} else {
				ret = true;
			}

			n_string_path_free( f_name );
			n_string_path_free( t_name );

			if ( ret == false ) { break; }

			i++;

		}

		if ( ret == false )
		{

			n_filer_remove( str );

			ret = true;

		} else {

			ret = false;

		}

	}

//n_vector_save_literal( &f_d.name, "./dir_f.txt", N_STRING_CRLF );
//n_vector_save_literal( &t_d.name, "./dir_t.txt", N_STRING_CRLF );

	n_dir_free( &f_d );
	n_dir_free( &t_d );


	n_string_path_free( tgt );
	n_string_path_free( nam );
	n_string_path_free( ext );
	n_string_path_free( tmp );
	n_string_path_free( str );


	n_win_cursor_add( NULL, IDC_ARROW );


	return ret;
}

bool
n_oc_dnd( const n_posix_char *f, const n_posix_char *t, int drag, bool sync_needed, bool *is_cancelled )
{
//n_posix_debug_literal( "%s\n%s", f, t ); return true;

	// [ Mechanism ]
	//
	//	drag / target            | File | Folder
	//	-----------------------------------------------
	//	N_ORANGECAT_DRAG_LBUTTON | exec | move / .lnk
	//	N_ORANGECAT_DRAG_MBUTTON | exec | .lnk
	//	N_ORANGECAT_DRAG_RBUTTON | exec | copy / clone


	if ( is_cancelled != NULL ) { (*is_cancelled) = false; }


	{

		extern bool n_oc_item_computer_is_droppable( n_oc_item* );

		if (
			( oc.view_is_computer )
			&&
			( false == n_oc_item_computer_is_droppable( &item ) )
		)
		{
//n_posix_debug_literal( " %d ", n_oc_item_computer_is_droppable( &item ) );
			return true;
		}

	}

	//if ( item.find_onoff ) { return true; }

	if ( n_string_is_empty( f ) ) { return true; }

	if ( n_string_path_is_drivename( f ) ) { return true; }


	n_posix_char *path;
	n_posix_char *args;

	if ( n_string_path_ext_is_same( N_ISHELLLINK_EXT, t ) )
	{
		path = n_string_path_new( N_OC_LNK2PATH_CCH_MAX );
		args = n_string_path_new( N_OC_LNK2PATH_CCH_MAX );

		n_oc_lnk2path( t, path, args );
//n_posix_debug_literal( "A\nF:%s\nT:%s\nP:%s", f, t, path ); return true;
	} else {
		path = n_string_path_carboncopy( t );
		args = n_string_path_carboncopy( N_STRING_EMPTY );
//n_posix_debug_literal( "B\nF:%s\nT:%s\nP:%s", f, t, path ); return true;
	}


	int target_type = n_posix_stat_type( path );

	if ( target_type == N_POSIX_STAT_TYPE_FILE )
	{

		n_posix_char *exe = n_string_path_cat( path, N_STRING_SPACE, args, N_STRING_SPACE, f, NULL );

		n_win_exec( exe, SW_NORMAL );

//n_string_replace( exe,exe, N_STRING_SPACE, L"?" );
//n_posix_debug( exe );

		n_string_path_free( exe );

	} else
	if ( target_type == N_POSIX_STAT_TYPE_DIRECTORY )
	{
//n_posix_debug_literal( "%s\n%s", oc.main, f );


		// [!] : Drop to the same folder

		n_posix_char *upper = n_string_path_upperfolder_new( f );
		n_string_path_drivename_slash_add( upper );
//n_posix_debug_literal( "%s\n%s\n%s", oc.main, upper, path );

		bool is_upper = ( n_string_is_same( oc.main, upper ) );

		n_string_path_free( upper );


		bool sync = false;

		if (
			( is_upper )
			&&
			( n_string_is_same( oc.main, path ) )
		)
		{

			bool ret = false;

			if ( drag == N_ORANGECAT_DRAG_LBUTTON )
			{
				n_IShellLink_path2lnk( (void*) f, (void*) f, NULL, NULL, 0 ); 
			} else
			if ( drag == N_ORANGECAT_DRAG_MBUTTON )
			{
				n_IShellLink_path2lnk( (void*) f, (void*) f, NULL, NULL, 0 );
			} else
			if ( drag == N_ORANGECAT_DRAG_RBUTTON )
			{
				ret = n_oc_dnd_clone( f, t );
			} else
			if ( drag == N_ORANGECAT_DRAG_VBUTTON )
			{
				ret = n_oc_dnd_clone( f, t );
			}

			if ( ret )
			{
				n_project_dialog_info( game.hwnd, n_project_string_error );
			} else {
				sync = true;
			}

		} else {

			n_posix_char *oldname = n_string_path_carboncopy( f );
			n_posix_char *midname = n_string_path_carboncopy( f ); n_string_path_name( midname, midname );
			n_posix_char *newname = n_string_path_make_new( path, midname );
			n_string_path_make( path, midname, newname );
//n_posix_debug_literal( "%s\n%s", oldname, newname );


			bool ret = false;

			if ( drag == N_ORANGECAT_DRAG_LBUTTON )
			{
				if ( n_posix_stat_is_dir( newname ) )
				{
					ret = n_win_filer_merge  ( game.hwnd, oldname, newname, is_cancelled );
					if ( ret == false ) { n_filer_remove( oldname ); }
				} else {
					ret = n_win_filer_move   ( game.hwnd, oldname, newname, is_cancelled );
				}
			} else
			if ( drag == N_ORANGECAT_DRAG_MBUTTON )
			{
				n_IShellLink_path2lnk( newname, (void*) f, NULL, NULL, 0 );
			} else
			if ( drag == N_ORANGECAT_DRAG_RBUTTON )
			{
				if ( n_posix_stat_is_dir( newname ) )
				{
					ret = n_win_filer_merge  ( game.hwnd, oldname, newname, is_cancelled );
				} else {
					ret = n_win_filer_replace( game.hwnd, oldname, newname, is_cancelled );
				}
			} else
			if ( drag == N_ORANGECAT_DRAG_VBUTTON )
			{
				ret = n_oc_dnd_clone( f, t );
			}

			if ( ret )
			{
				n_project_dialog_info( game.hwnd, n_project_string_error );
			} else {
				if ( ( is_cancelled != NULL )&&( (*is_cancelled) == false ) ) { sync = true; }
			}


			n_string_path_free( oldname );
			n_string_path_free( midname );
			n_string_path_free( newname );

		}


		if ( ( sync_needed )&&( sync ) )
		{
			n_oc_event_itemsync();
		}

	}


	n_string_path_free( path );
	n_string_path_free( args );


	return false;
}

bool
n_oc_patch_is_recyclebin( const n_posix_char *path )
{

	bool ret = false;


	if ( n_string_is_same_literal( "$RECYCLE.BIN", path ) ) { return true; }

	{

		n_posix_char *s = n_string_path_name_new( path );
		if ( n_string_is_same_literal( "$RECYCLE.BIN", s ) ) { ret = true; }
		n_string_path_free( s );

		if ( ret ) { return ret; }
	}


	if ( false == n_posix_stat_is_dir( path ) ) { return false; }


	// [Patch] : crash sometimes : see win32/gdi/icon.c

	const n_posix_char *name = n_posix_literal( "Desktop.ini" );
	const n_posix_char *sect = n_posix_literal( "[.ShellClassInfo]" );
	const n_posix_char *lval = n_posix_literal( "CLSID" );
	const n_posix_char *rval = n_posix_literal( "{645FF040-5081-101B-9F08-00AA002F954E}" );


	n_posix_char *desktop_ini = n_string_path_make_new( path, name );
//n_posix_debug_literal( "%s", desktop_ini );
	n_ini ini; n_ini_zero( &ini ); n_ini_load( &ini, desktop_ini );
	n_string_path_free( desktop_ini );


	n_posix_char *str = n_ini_value_str_new( &ini, sect, lval, N_STRING_EMPTY );
	if ( n_string_is_same( str, rval ) )
	{
//n_posix_debug_literal( "%s", path );
		ret = true;
	}
//n_posix_debug_literal( "%s\n%s", str, rval );
	n_string_path_free( str );


	n_ini_free( &ini );


//ret = true;
	return ret;
}

int
n_oc_patch_iconpath_index( const n_posix_char *path_default, bool is_computer_on_breadcrumb )
{

	int index = 0;


	if ( is_computer_on_breadcrumb )
	{

		index = 15;

	} else
	if ( oc.view_is_computer )
	{

		if ( n_string_is_same( path_default, oc.cpnl ) )
		{

			if ( n_sysinfo_version_95()          ) { index =  35; } else
			if ( n_sysinfo_version_9x()          ) { index =  51; } else
			if ( n_sysinfo_version_2000()        ) { index =  57; } else
			if ( n_sysinfo_version_xp_or_later() ) { index = 207; }// else

		} else
		if ( n_string_is_same( path_default, N_ORANGECAT_SETTINGS_EXE ) )
		{

			index = 0;

			// [!] : this code is Win10 only

			//index = 315;

		} else
		if ( n_string_is_same( path_default, N_ORANGECAT_SHUTDOWN_EXE ) )
		{

			index = 27;

		} else {

			index = 0;

		}

	} else
	if ( n_string_is_same( N_ORANGECAT_FIND, path_default ) )
	{

		index = 22;

	} else {

		if ( n_oc_patch_is_recyclebin( path_default ) )
		{
			index = 31;
		} else {
			index = 0;
		}

	}


	return index;
}

n_posix_char*
n_oc_patch_iconpath_new( const n_posix_char *path_default, bool is_computer_on_breadcrumb )
{

	n_posix_char *ret = NULL;


	if ( is_computer_on_breadcrumb )
	{

		n_posix_char *sys = n_string_path_new( MAX_PATH ); GetSystemDirectory( sys, MAX_PATH );
		n_posix_char *exe = n_posix_literal( "shell32.dll" );

		ret = n_string_path_make_new( sys, exe );

		n_string_path_free( sys );

	} else
	if ( oc.view_is_computer )
	{

		if ( n_string_is_same( path_default, oc.cpnl ) )
		{

			n_posix_char *sys = n_string_path_new( MAX_PATH ); GetSystemDirectory( sys, MAX_PATH );
			n_posix_char *exe = n_posix_literal( "shell32.dll" );

			ret = n_string_path_make_new( sys, exe );

			n_string_path_free( sys );

		} else
		if ( n_string_is_same( path_default, N_ORANGECAT_SETTINGS_EXE ) )
		{

			n_posix_char *win = n_string_path_new( MAX_PATH ); GetWindowsDirectory( win, MAX_PATH );
			n_posix_char *exe = n_posix_literal( "ImmersiveControlPanel\\SystemSettings.exe" );

			ret = n_string_path_make_new( win, exe );
//n_posix_debug_literal( " %s ", ret );

			n_string_path_free( win );


			// [!] : this code is Win10 only
/*
			n_posix_char *sys = n_string_path_new( MAX_PATH ); GetSystemDirectory( sys, MAX_PATH );
			n_posix_char *exe = n_posix_literal( "shell32.dll" );

			ret = n_string_path_make_new( sys, exe );

			n_string_path_free( sys );
*/
		} else
		if ( n_string_is_same( path_default, N_ORANGECAT_SHUTDOWN_EXE ) )
		{

			n_posix_char *sys = n_string_path_new( MAX_PATH ); GetSystemDirectory( sys, MAX_PATH );
			n_posix_char *exe = n_posix_literal( "shell32.dll" );

			ret = n_string_path_make_new( sys, exe );

			n_string_path_free( sys );

		} else {

			ret = n_string_path_carboncopy( path_default );

		}

	} else
	if ( n_string_is_same( N_ORANGECAT_FIND, path_default ) )
	{

		n_posix_char *sys = n_string_path_new( MAX_PATH ); GetSystemDirectory( sys, MAX_PATH );
		n_posix_char *exe = n_posix_literal( "shell32.dll" );

		ret = n_string_path_make_new( sys, exe );

		n_string_path_free( sys );

	} else {
//n_posix_debug_literal( "%s", path_default );

		if ( n_oc_patch_is_recyclebin( path_default ) )
		{

			n_posix_char *sys = n_string_path_new( MAX_PATH ); GetSystemDirectory( sys, MAX_PATH );
			n_posix_char *exe = n_posix_literal( "shell32.dll" );

			ret = n_string_path_make_new( sys, exe );
//n_posix_debug_literal( " %s ", ret );

			n_string_path_free( sys );

		} else {

			ret = n_string_path_carboncopy( path_default );

		}

	}


	return ret;
}


