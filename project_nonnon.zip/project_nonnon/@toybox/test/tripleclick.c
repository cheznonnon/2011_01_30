



#include "../../nonnon/win32/win.c"

#include "../../nonnon/project/macro.c"




static WNDPROC p_func = NULL;




LRESULT CALLBACK
n_tripleclick_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{


	static DWORD tmr = 0;


	switch( msg ) {


	case WM_LBUTTONDBLCLK :
SetWindowText( GetParent( hwnd ), "WM_LBUTTONDBLCLK" );

		tmr = GetTickCount();

	break;

	case WM_LBUTTONDOWN :
SetWindowText( GetParent( hwnd ), "WM_LBUTTONDOWN" );

		if ( tmr == 0 ) { break; }

		if ( ( GetTickCount() - tmr ) < GetDoubleClickTime() )
		{
SetWindowText( GetParent( hwnd ), "Triple Clicked" );

			int y   = n_win_message_send( hwnd, EM_LINEFROMCHAR, -1, 0 );
			int cch = n_win_message_send( hwnd, EM_LINEINDEX,    -1, 0 );
			int len = n_win_message_send( hwnd, EM_LINELENGTH,    y, 0 );

			n_win_message_send( hwnd, EM_SETSEL, cch, cch + len );

			//n_win_message_remove();

			tmr = 0;

			return false;

		}

		tmr = 0;

	break;


	} // switch


	return CallWindowProc( p_func, hwnd, msg, wparam, lparam );
}

LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static HWND hgui[ 2 ];


	switch( msg ) {


	case WM_CREATE :


		n_win_init_literal( hwnd, "Triple Click Subclass", "", "" );

		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );


		n_win_set( hwnd, NULL, 256,256, N_WIN_SET_CENTERING );


		n_win_gui_literal( hwnd, INPUT,  "", &hgui[ 0 ] );
		n_win_gui_literal( hwnd, EDITOR, "", &hgui[ 1 ] );

		n_win_text_set( hgui[ 0 ], "test test test" );
		n_win_text_set( hgui[ 1 ], "test test test\r\ntest test test" );

		n_win_move_simple( hgui[ 0 ], 0, 0,256,30, true );
		n_win_move_simple( hgui[ 1 ], 0,30,256,90, true );

		p_func = n_win_gui_subclass_set( hgui[ 0 ], n_tripleclick_wndproc );
		p_func = n_win_gui_subclass_set( hgui[ 1 ], n_tripleclick_wndproc );


		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}

