// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include <commdlg.h>




// internal
void
n_catpad_printer_gdi( HWND hwnd, HDC hdc, s32 sx, s32 sy, int font_pt, n_posix_char *cmdline )
{

	n_gdi gdi; n_gdi_zero( &gdi );


	gdi.sx                  = sx;
	gdi.sy                  = sy;
	gdi.scale               = 1;//N_GDI_SCALE_AUTO;
	gdi.style               = N_GDI_DEFAULT;//N_GDI_AUTOMARGIN;
	gdi.layout              = N_GDI_LAYOUT_HORIZONTAL;
	gdi.align               = N_GDI_ALIGN_LEFT | N_GDI_ALIGN_TOP;

	gdi.frame_style         = N_GDI_FRAME_TRANS;

	gdi.base_color_bg       = n_bmp_rgb( 255,255,255 );
	gdi.base_color_fg       = n_bmp_rgb( 255,255,255 );
	gdi.base_style          = N_GDI_BASE_SOLID;

	gdi.text                = cmdline;
	gdi.text_font           = n_font_name( n_catpad_hfont );
	gdi.text_size           = font_pt;
	gdi.text_style          = N_GDI_TEXT_PRINTER | N_GDI_TEXT_MONOSPACE_2;
	gdi.text_color_main     = n_bmp_rgb(  10, 10, 10 );


	n_bmp bmp; n_bmp_zero( &bmp ); 

//n_posix_debug_literal( " %d %d ", font_pt, sx / 100 );
	if ( font_pt < 10 )
	{

/*
		// [!] : 64-bit only : too much heavy

		// [x] : 32-bit version : integer overflow happens

		gdi.sy        = 0;
		gdi.text_size = 10;

		gdi.style |= N_GDI_CALCONLY;

		n_gdi_bmp( &gdi, NULL );

		gdi.style &= ~N_GDI_CALCONLY;


		n_bmp_new( &bmp, gdi.sx, gdi.sy );
//n_posix_debug_literal( "%d %d", gdi.sx, gdi.sy );

		n_gdi_bmp( &gdi, &bmp );
//n_bmp_save_literal( &bmp, "test.bmp" );


		s32 y = 0;
		while( 1 )
		{break;

			StartPage( hdc );

			n_gdi_bitmap_draw_main( hwnd, hdc, &bmp, 0,y,sx,sy, 0,0 );

			EndPage( hdc );

			y += sy;
			if ( y >= gdi.sy ) { break; }
		}
*/

	} else {

		n_bmp_new( &bmp, gdi.sx, gdi.sy );

		gdi.style |= N_GDI_CALCONLY;
		while( 1 )
		{//break;
			n_gdi_bmp( &gdi, NULL );
//n_posix_debug_literal( "%d/%d : %d/%d", gdi.text_sx, gdi.sx, gdi.text_sy, gdi.sy );

			if (
				( ( ( gdi.offset_x * 2 ) + gdi.text_sx ) >= gdi.sx )
				||
				( ( ( gdi.offset_y * 4 ) + gdi.text_sy ) >= gdi.sy )
			)
			{
//n_posix_debug_literal( " %d %d ", gdi.offset_x, gdi.offset_y );
				break;
			}

			gdi.text_size++;
		}
		gdi.style &= ~N_GDI_CALCONLY;

		n_gdi_bmp( &gdi, &bmp );
//n_bmp_save_literal( &bmp, "test.bmp" );

		n_gdi_bitmap_draw_main( hwnd, hdc, &bmp, 0,0,sx,sy, 0,0 );

	}


	n_bmp_free_fast( &bmp );


	return;
}
/*
// internal
int CALLBACK
n_catpad_printer_font_enumfontsproc( const LOGFONT *lf, const TEXTMETRIC *tm, DWORD type, LPARAM lparam )
{

	// [Mechanism] : type
	//
	//	DEVICE_FONTTYPE
	//	RASTER_FONTTYPE
	//	TRUETYPE_FONTTYPE

	// [!] : lfPitchAndFamily : FIXED_PITCH : bitmap fonts are only returned


	LOGFONT *query = (LOGFONT*) lparam;


	if (
		( type == DEVICE_FONTTYPE )
		&&
		( query->lfPitchAndFamily == FIXED_PITCH )
	)
	{
//n_posix_debug_literal( "%s : %s", lf->lfFaceName, query->lfFaceName );

		n_memory_copy( lf, query, sizeof( LOGFONT ) );


		return false;
	}


	return true;
}

HFONT
n_catpad_printer_font( HDC hdc, HFONT hfont_base, s32 size )
{

	LOGFONT lf;


	n_win_font_hfont2logfont( hfont_base );

	//EnumFonts( hdc, NULL, n_catpad_printer_font_enumfontsproc, (LPARAM) &lf );


	lf.lfWidth  = 0;
	lf.lfHeight = size;


	return n_win_font_logfont2hfont( &lf );
}
*/
void
n_catpad_printer( HWND hwnd, HFONT hfont_base, n_txt *txt )
{

	PRINTDLG pd; ZeroMemory( &pd, sizeof( PRINTDLG ) );

	pd.lStructSize = sizeof( PRINTDLG );
	pd.hwndOwner   = hwnd;
	pd.Flags       = PD_RETURNDC | PD_HIDEPRINTTOFILE | PD_DISABLEPRINTTOFILE | PD_NOSELECTION;

	if ( PrintDlg( &pd ) )
	{
//u32 tick = n_posix_tickcount();

		HDC hdc = pd.hDC;


		// [!] : HORZRES / VERTRES : unit is large pixel

		s32 sx = GetDeviceCaps( hdc, HORZRES );
		s32 sy = GetDeviceCaps( hdc, VERTRES );
//n_win_hwndprintf_literal( hwnd, "%d %d", sx, sy );

		n_txt_stream( txt );

		s32 cch_x = n_posix_max( 1, txt->sx );
		s32 cch_y = n_posix_max( 1, txt->sy );
//n_posix_debug_literal( "%d %d", cch_x, cch_y );

		s32 font_sx = sx / cch_x;
		s32 font_sy = sy / cch_y;
//n_posix_debug_literal( "%d %d", font_sx, font_sy );

		int font_pt = (double) n_posix_min( font_sx, font_sy ) * 0.75;

		if ( font_pt < 10 )
		{

			n_project_dialog_info( hwnd, n_posix_literal( "multi-page is needed, use other softwares" ) );

		} else {

			DOCINFO di; ZeroMemory( &di,sizeof( DOCINFO ) );
			di.cbSize = sizeof( DOCINFO );

			StartDoc( hdc, &di );


			n_win_cursor_add( NULL, IDC_WAIT );


			n_catpad_printer_gdi( hwnd, hdc, sx,sy, font_pt, txt->stream );


			// [!] : monospace : you can never get a monospace font

			//HFONT hfont = n_catpad_printer_font( hdc, hfont_base, -font_pt );
			//HFONT hfprv = SelectObject( hdc, hfont );

			//s32 ox = font_sx / 2;
			//s32 oy = font_sy / 2;

			//RECT r = { ox,oy,sx-(ox*2),sy-(oy*2) };
			//DrawText( hdc, txt->stream,-1, &r, DT_EXPANDTABS );

			//DeleteObject( SelectObject( hdc, hfprv ) );


			EndDoc( hdc );


			// [!] : EndDoc() will restore a cursor
			//n_win_cursor_add( NULL, IDC_ARROW );

		}


		DeleteObject( hdc );

//n_posix_debug_literal( "%d", (int) n_posix_tickcount() - tick ); // 20172 9038 7656
	}


	return;
}


