// nmixer
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Link : -lwinmm -lole32


// [Mechanism] : you only need to know these two macro functions
//
//	Get : n_mixer_get( int *vol_percent );
//	Set : n_mixer_set( int *vol_percent );


// [!] : if you break LR volume balance while debugging
//
//	uninstall/reinstall your sound driver




#ifndef _H_NONNON_WIN32_MIXER
#define _H_NONNON_WIN32_MIXER




#include "../neutral/posix.c"

#include "./sysinfo/version.c"


#include <mmsystem.h>
#include <ocidl.h>

#ifdef _MSC_VER
#pragma comment( lib, "winmm" )
#pragma comment( lib, "ole32" )
#endif // #ifdef _MSC_VER




#define N_MIXER_GET 0
#define N_MIXER_SET 1




#define n_mixer_debug_literal( a,b,c ) n_mixer_debug( n_posix_literal( a ), b, c )

// internal
void
n_mixer_debug( const n_posix_char *title, int ret, int val )
{

	n_posix_debug_literal
	(
		"%s \nRet %d \nVal %d \n",
		title, ret, val
	);


	return;
}

// internal
bool
n_mixer_classic( int *vol_percent, int getset )
{

	HMIXER              hmixer;
	HMIXEROBJ           hmo;
	UINT                id_max, id;
	//MIXERCAPSA          mcaps;
	MIXERLINEA          ml;
	MIXERLINECONTROLSA  mlc;
	MIXERCONTROLA       mc;
	MIXERCONTROLDETAILS d;
	DWORD               volume;
	DWORD               ret;


	if ( vol_percent == NULL ) { return true; }


	id_max = mixerGetNumDevs();
	if ( id_max == 0 ) { return true; }


	id = 0;
	while( 1 )
	{

		// [!] : this will succeed always

		ret = mixerOpen( &hmixer, id, 0, 0, MIXER_OBJECTF_MIXER );
		hmo = (HMIXEROBJ) hmixer;

//mixerGetID( hmo, &id, MIXER_OBJECTF_HMIXER );
//n_mixer_debug_literal( "mixerOpen", ret, id );

//n_posix_debug_literal( "%x", (int) hmixer );


		// [!] : Win9x : MSLU returns 8 (MMSYSERR_NOTSUPPORTED)

		ZeroMemory( &ml, sizeof( MIXERLINEA ) );

		ml.cbStruct        = sizeof( MIXERLINEA );
		ml.dwComponentType = MIXERLINE_COMPONENTTYPE_DST_SPEAKERS;

		ret = mixerGetLineInfoA
		(
			hmo,
			&ml,
			MIXER_OBJECTF_HMIXER |
			MIXER_GETLINEINFOF_COMPONENTTYPE
		);

//n_mixer_debug_literal( "mixerGetLineInfo", ret, ml.dwLineID );

		if ( ret == 0 ) { break; }


		mixerClose( hmixer );


		id++;
		if ( id >= id_max ) { return true; }
	}


	// [!] : MIXERLINE.dwLineID : always returns 0xffff0000(-65536)

	ZeroMemory( &mlc, sizeof( MIXERLINECONTROLSA ) );
	ZeroMemory( &mc,  sizeof( MIXERCONTROLA      ) );

	mlc.cbStruct      = sizeof( MIXERLINECONTROLSA );
	mlc.cControls     = 1;
	mlc.cbmxctrl      = sizeof( MIXERCONTROLA );
	mlc.pamxctrl      = &mc;

	mlc.dwLineID      = ml.dwLineID;
	mlc.dwControlType = MIXERCONTROL_CONTROLTYPE_VOLUME;

	ret = mixerGetLineControlsA
	(
		hmo,
		&mlc,
		MIXER_OBJECTF_HMIXER |
		MIXER_GETLINECONTROLSF_ONEBYTYPE
	);

//n_mixer_debug_literal( "mixerGetLineControls", ret, mc.dwControlID );

	if ( ret ) { return true; }


	// [!] : Why not d.cChannels = MIXERLINE.cChannels ?
	//
	//	adjust stereo/pan setting to center

	ZeroMemory( &d, sizeof( MIXERCONTROLDETAILS ) );

	d.cbStruct    = sizeof( MIXERCONTROLDETAILS );
	d.dwControlID = mc.dwControlID;
	d.cChannels   = 1;
	d.cbDetails   = sizeof( DWORD );
	d.paDetails   = &volume;

	if ( getset == N_MIXER_GET )
	{

		double v;


		volume = 0;

		ret = mixerGetControlDetailsA
		(
			hmo,
			&d,
			MIXER_OBJECTF_HMIXER |
			MIXER_SETCONTROLDETAILSF_VALUE
		);

//n_mixer_debug_literal( "mixerGetControlDetails", ret, 0 );


		v = (double) volume / 0xffff;
		v = (double) 100 * v;


		// [Needed] : rounding

		(*vol_percent) = ceil( v );

	} else {

		double v;


		v = (double) (*vol_percent) / 100;
		v = 0xffff * v;

		volume = v;


		ret = mixerSetControlDetails
		(
			hmo,
			&d,
			MIXER_OBJECTF_HMIXER |
			MIXER_SETCONTROLDETAILSF_VALUE
		);

//n_mixer_debug_literal( "mixerSetControlDetails", ret, 0 );

	}


	mixerClose( hmixer );


	return false;
}




#ifdef _MSC_VER


#include <mmdeviceapi.h>
#include <endpointvolume.h>


#define n_PAUDIO_VOLUME_NOTIFICATION_DATA PAUDIO_VOLUME_NOTIFICATION_DATA


#else  // #endif // #ifdef _MSC_VER


#ifndef __mmdeviceapi_h__


#define IMMDeviceCollection   int
#define IMMNotificationClient int
#define PROPVARIANT           int
#define IPropertyStore        int


typedef enum {

	eRender,
	eCapture,
	eAll,
	EDataFlow_enum_count

} EDataFlow;

typedef enum {

	eConsole,
	eMultimedia,
	eCommunications,
	ERole_enum_count

} ERole;


EXTERN_C const IID IID_IMMDevice;
#define INTERFACE IMMDevice
DECLARE_INTERFACE_( IMMDevice, IUnknown )
{
	STDMETHOD ( QueryInterface   )( THIS_ REFIID, PVOID*                      ) PURE;
	STDMETHOD_( ULONG, AddRef    )( THIS                                      ) PURE;
	STDMETHOD_( ULONG, Release   )( THIS                                      ) PURE;

	STDMETHOD( Activate          )( THIS_ REFIID, DWORD, PROPVARIANT*, void** ) PURE;
	STDMETHOD( OpenPropertyStore )( THIS_ DWORD, IPropertyStore**             ) PURE;
	STDMETHOD( GetId             )( THIS_ LPWSTR*                             ) PURE;
	STDMETHOD( GetState          )( THIS_ DWORD*                              ) PURE;
};
#undef INTERFACE

#define IMMDevice_QueryInterface(    p, a,b     ) (p)->lpVtbl->QueryInterface(    p, a,b     )
#define IMMDevice_AddRef(            p          ) (p)->lpVtbl->AddRef(            p          )
#define IMMDevice_Release(           p          ) (p)->lpVtbl->Release(           p          )
#define IMMDevice_Activate(          p, a,b,c,d ) (p)->lpVtbl->Activate(          p, a,b,c,d )
#define IMMDevice_OpenPropertyStore( p, a,b     ) (p)->lpVtbl->OpenPropertyStore( p, a,b     )
#define IMMDevice_GetId(             p, a       ) (p)->lpVtbl->GetId(             p, a       )
#define IMMDevice_GetState(          p, a       ) (p)->lpVtbl->GetState(          p, a       )


EXTERN_C const IID IID_IMMDeviceEnumerator;
#define INTERFACE IMMDeviceEnumerator
DECLARE_INTERFACE_( IMMDeviceEnumerator, IUnknown )
{
	STDMETHOD ( QueryInterface                        )( THIS_ REFIID, PVOID*                          ) PURE;
	STDMETHOD_( ULONG, AddRef                         )( THIS                                          ) PURE;
	STDMETHOD_( ULONG, Release                        )( THIS                                          ) PURE;

	STDMETHOD( EnumAudioEndpoints                     )( THIS_ EDataFlow, DWORD, IMMDeviceCollection** ) PURE;
	STDMETHOD( GetDefaultAudioEndpoint                )( THIS_ EDataFlow, ERole, IMMDevice**           ) PURE;
	STDMETHOD( GetDevice                              )( THIS_ LPCWSTR, IMMDevice**                    ) PURE;
	STDMETHOD( RegisterEndpointNotificationCallback   )( THIS_ IMMNotificationClient*                  ) PURE;
	STDMETHOD( UnregisterEndpointNotificationCallback )( THIS_ IMMNotificationClient*                  ) PURE;
};
#undef INTERFACE

#define IMMDeviceEnumerator_QueryInterface(                         p, a,b   ) (p)->lpVtbl->QueryInterface(                         p, a,b   )
#define IMMDeviceEnumerator_AddRef(                                 p        ) (p)->lpVtbl->AddRef(                                 p        )
#define IMMDeviceEnumerator_Release(                                p        ) (p)->lpVtbl->Release(                                p        )
#define IMMDeviceEnumerator_EnumAudioEndpoints(                     p, a,b,c ) (p)->lpVtbl->EnumAudioEndpoints(                     p, a,b,c )
#define IMMDeviceEnumerator_GetDefaultAudioEndpoint(                p, a,b,c ) (p)->lpVtbl->GetDefaultAudioEndpoint(                p, a,b,c )
#define IMMDeviceEnumerator_GetDevice(                              p, a,b   ) (p)->lpVtbl->GetDevice(                              p, a,b   )
#define IMMDeviceEnumerator_RegisterEndpointNotificationCallback(   p, a     ) (p)->lpVtbl->RegisterEndpointNotificationCallback(   p, a     )
#define IMMDeviceEnumerator_UnregisterEndpointNotificationCallback( p, a     ) (p)->lpVtbl->UnregisterEndpointNotificationCallback( p, a     )


#endif // #ifndef __mmdeviceapi_h__


#ifndef __endpointvolume_h__


typedef struct n_AUDIO_VOLUME_NOTIFICATION_DATA {

	GUID  guidEventContext;
	BOOL  bMuted;
	float fMasterVolume;
	UINT  nChannels;
	float afChannelVolumes[ 1 ];

} n_AUDIO_VOLUME_NOTIFICATION_DATA, *n_PAUDIO_VOLUME_NOTIFICATION_DATA;

EXTERN_C const IID IID_IAudioEndpointVolumeCallback;
#define INTERFACE IAudioEndpointVolumeCallback
DECLARE_INTERFACE_( IAudioEndpointVolumeCallback, IUnknown )
{
	STDMETHOD ( QueryInterface               )( THIS_ REFIID, PVOID*                    ) PURE;
	STDMETHOD_( ULONG, AddRef                )( THIS                                    ) PURE;
	STDMETHOD_( ULONG, Release               )( THIS                                    ) PURE;

	STDMETHOD( OnNotify                      )( THIS_ n_PAUDIO_VOLUME_NOTIFICATION_DATA ) PURE;
};
#undef INTERFACE

EXTERN_C const IID IID_IAudioEndpointVolume;
#define INTERFACE IAudioEndpointVolume
DECLARE_INTERFACE_( IAudioEndpointVolume, IUnknown )
{
	STDMETHOD ( QueryInterface               )( THIS_ REFIID, PVOID*                ) PURE;
	STDMETHOD_( ULONG, AddRef                )( THIS                                ) PURE;
	STDMETHOD_( ULONG, Release               )( THIS                                ) PURE;

	STDMETHOD( RegisterControlChangeNotify   )( THIS_ IAudioEndpointVolumeCallback* ) PURE;
	STDMETHOD( UnregisterControlChangeNotify )( THIS_ IAudioEndpointVolumeCallback* ) PURE;
	STDMETHOD( GetChannelCount               )( THIS_ UINT*                         ) PURE;
	STDMETHOD( SetMasterVolumeLevel          )( THIS_ float, LPCGUID                ) PURE;
	STDMETHOD( SetMasterVolumeLevelScalar    )( THIS_ float, LPCGUID                ) PURE;
	STDMETHOD( GetMasterVolumeLevel          )( THIS_ float*                        ) PURE;
	STDMETHOD( GetMasterVolumeLevelScalar    )( THIS_ float*                        ) PURE;
	STDMETHOD( SetChannelVolumeLevel         )( THIS_ UINT, float, LPCGUID          ) PURE;
	STDMETHOD( SetChannelVolumeLevelScalar   )( THIS_ UINT, float, LPCGUID          ) PURE;
	STDMETHOD( GetChannelVolumeLevel         )( THIS_ UINT, float*                  ) PURE;
	STDMETHOD( GetChannelVolumeLevelScalar   )( THIS_ UINT, float*                  ) PURE;
	STDMETHOD( SetMute                       )( THIS_ BOOL                          ) PURE;
	STDMETHOD( GetMute                       )( THIS_ BOOL*                         ) PURE;
	STDMETHOD( GetVolumeStepInfo             )( THIS_ UINT*, UINT*                  ) PURE;
	STDMETHOD( VolumeStepUp                  )( THIS_ LPCGUID                       ) PURE;
	STDMETHOD( VolumeStepDown                )( THIS_ LPCGUID                       ) PURE;
	STDMETHOD( QueryHardwareSupport          )( THIS_ DWORD*                        ) PURE;
	STDMETHOD( GetVolumeRange                )( THIS_ float*, float*, float*        ) PURE;
};
#undef INTERFACE

#define IAudioEndpointVolume_QueryInterface(                p, a,b   ) (p)->lpVtbl->QueryInterface(                p, a,b   )
#define IAudioEndpointVolume_AddRef(                        p        ) (p)->lpVtbl->AddRef(                        p        )
#define IAudioEndpointVolume_Release(                       p        ) (p)->lpVtbl->Release(                       p        )
#define IAudioEndpointVolume_RegisterControlChangeNotify(   p, a     ) (p)->lpVtbl->RegisterControlChangeNotify(   p, a     )
#define IAudioEndpointVolume_UnregisterControlChangeNotify( p, a     ) (p)->lpVtbl->UnregisterControlChangeNotify( p, a     )
#define IAudioEndpointVolume_GetChannelCount(               p, a     ) (p)->lpVtbl->GetChannelCount(               p, a     )
#define IAudioEndpointVolume_SetMasterVolumeLevel(          p, a,b   ) (p)->lpVtbl->SetMasterVolumeLevel(          p, a,b   )
#define IAudioEndpointVolume_SetMasterVolumeLevelScalar(    p, a,b   ) (p)->lpVtbl->SetMasterVolumeLevelScalar(    p, a,b   )
#define IAudioEndpointVolume_GetMasterVolumeLevel(          p, a     ) (p)->lpVtbl->GetMasterVolumeLevel(          p, a     )
#define IAudioEndpointVolume_GetMasterVolumeLevelScalar(    p, a     ) (p)->lpVtbl->GetMasterVolumeLevelScalar(    p, a     )
#define IAudioEndpointVolume_SetChannelVolumeLevel(         p, a,b,c ) (p)->lpVtbl->SetChannelVolumeLevel(         p, a,b,c )
#define IAudioEndpointVolume_SetChannelVolumeLevelScalar(   p, a,b,c ) (p)->lpVtbl->SetChannelVolumeLevelScalar(   p, a,b,c )
#define IAudioEndpointVolume_GetChannelVolumeLevel(         p, a,b   ) (p)->lpVtbl->GetChannelVolumeLevel(         p, a,b   )
#define IAudioEndpointVolume_GetChannelVolumeLevelScalar(   p, a,b   ) (p)->lpVtbl->GetChannelVolumeLevelScalar(   p, a,b   )
#define IAudioEndpointVolume_SetMute(                       p, a     ) (p)->lpVtbl->SetMute(                       p, a     )
#define IAudioEndpointVolume_GetMute(                       p, a     ) (p)->lpVtbl->GetMute(                       p, a     )
#define IAudioEndpointVolume_GetVolumeStepInfo(             p, a,b   ) (p)->lpVtbl->GetVolumeStepInfo(             p, a,b   )
#define IAudioEndpointVolume_VolumeStepUp(                  p, a     ) (p)->lpVtbl->VolumeStepUp(                  p, a     )
#define IAudioEndpointVolume_VolumeStepDown(                p, a     ) (p)->lpVtbl->VolumeStepDown(                p, a     )
#define IAudioEndpointVolume_QueryHardwareSupport(          p, a     ) (p)->lpVtbl->QueryHardwareSupport(          p, a     )
#define IAudioEndpointVolume_GetVolumeRange(                p, a,b,c ) (p)->lpVtbl->GetVolumeRange(                p, a,b,c )


#endif // #ifndef __endpointvolume_h__


#endif // #ifdef _MSC_VER


const GUID n_mixer_GUID_NULL                = { 0x00000000,0x0000,0x0000,{ 0x00,0x00, 0x00,0x00,0x00,0x00,0x00,0x00 } };
const GUID n_mixer_IID_IUnknown             = { 0x00000000,0x0000,0x0000,{ 0xC0,0x00, 0x00,0x00,0x00,0x00,0x00,0x46 } };
const GUID n_mixer_CLSID_MMDeviceEnumerator = { 0xBCDE0395,0xE52F,0x467C,{ 0x8E,0x3D, 0xC4,0x57,0x92,0x91,0x69,0x2E } };
const GUID n_mixer_IID_IAudioEndpointVolume = { 0x5CDF2C82,0x841E,0x4546,{ 0x97,0x22, 0x0C,0xF7,0x40,0x78,0x22,0x9A } };


// internal
bool
n_mixer_vista( int *vol_percent, bool getset )
{

	if ( vol_percent == NULL ) { return true; }


	HRESULT hr;


	IMMDeviceEnumerator  *IMMDeviceEnumerator  = NULL;
	IMMDevice            *IMMDevice            = NULL;
	IAudioEndpointVolume *IAudioEndpointVolume = NULL;


	CoInitialize( NULL );


	hr = CoCreateInstance
	(
		&n_mixer_CLSID_MMDeviceEnumerator,
		NULL,
		CLSCTX_ALL,
		&n_mixer_IID_IUnknown,
		(void*) &IMMDeviceEnumerator
	);

	if ( FAILED( hr )||( IMMDeviceEnumerator == NULL ) )
	{
//n_posix_debug_literal( " CoCreateInstance() " );
		goto cleanup;
	}


	hr = IMMDeviceEnumerator_GetDefaultAudioEndpoint
	(
		IMMDeviceEnumerator,
		eRender,
		eConsole,
		(void*) &IMMDevice
	);

	if ( FAILED( hr )||( IMMDevice == NULL ) )
	{
//n_posix_debug_literal( " IMMDeviceEnumerator_GetDefaultAudioEndpoint() " );
		goto cleanup;
	}


	hr = IMMDevice_Activate
	(
		IMMDevice,
		&n_mixer_IID_IAudioEndpointVolume,
		CLSCTX_ALL,
		NULL,
		(void*) &IAudioEndpointVolume
	);

	if ( FAILED( hr )||( IAudioEndpointVolume == NULL ) )
	{
//n_posix_debug_literal( "Activate" );
		goto cleanup;
	}


	if ( getset == N_MIXER_GET )
	{

		float v;

		IAudioEndpointVolume_GetMasterVolumeLevelScalar( IAudioEndpointVolume, &v );

		(*vol_percent) = v * 100;

	} else {

		float v = (float) (*vol_percent) / 100;

		v += 0.004f;
		if ( v >= 1.0 ) { v = 1.0; }

		IAudioEndpointVolume_SetMasterVolumeLevelScalar( IAudioEndpointVolume, v, &n_mixer_GUID_NULL );

	}

	hr = S_OK;


	cleanup:

	if ( IAudioEndpointVolume ) { IAudioEndpointVolume_Release( IAudioEndpointVolume ); }
	if ( IMMDevice            ) { IMMDevice_Release           ( IMMDevice            ); }
	if ( IMMDeviceEnumerator  ) { IMMDeviceEnumerator_Release ( IMMDeviceEnumerator  ); }

	CoUninitialize();


	return FAILED( hr );
}




#define n_mixer_get( v ) n_mixer( v, N_MIXER_GET )
#define n_mixer_set( v ) n_mixer( v, N_MIXER_SET )

bool
n_mixer( int *vol_percent, bool getset )
{

	// [!] : integrated function

	bool ret;


	if ( n_sysinfo_version_vista_or_later() )
	{
		ret = n_mixer_vista( vol_percent, getset );
	} else {
		ret = n_mixer_classic( vol_percent, getset );
	}


	return ret;
}


#endif // _H_NONNON_WIN32_MIXER

