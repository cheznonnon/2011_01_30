// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_WIN_IME
#define _H_NONNON_WIN32_WIN_IME




#include <imm.h>




void
n_win_ime_disable( HWND hwnd )
{

	HMODULE hmod;
	FARPROC func;


	hmod = LoadLibrary( n_posix_literal( "imm32.dll" ) );
	if ( hmod == NULL ) { return; }

	func = GetProcAddress( hmod, "ImmAssociateContext" );

	if ( func != NULL )
	{
		(*func)( hwnd, NULL );
	}

	FreeLibrary( hmod );


	return;
}

void
n_win_ime_enable( HWND hwnd )
{

	HMODULE hmod = LoadLibrary( n_posix_literal( "imm32.dll" ) );
	if ( hmod == NULL ) { return; }

	FARPROC n_ImmCreateContext    = GetProcAddress( hmod, "ImmCreateContext"    );
	FARPROC n_ImmAssociateContext = GetProcAddress( hmod, "ImmAssociateContext" );

	if (
		( n_ImmCreateContext    != NULL )
		&&
		( n_ImmAssociateContext != NULL )
	)
	{
		n_ImmAssociateContext( hwnd, n_ImmCreateContext() );
	}

	FreeLibrary( hmod );


	return;
}

bool
n_win_ime_is_on( HWND hwnd )
{

	bool ret = false;


	HMODULE hmod = LoadLibrary( n_posix_literal( "imm32.dll" ) );
	if ( hmod == NULL ) { return ret; }

	FARPROC n_ImmGetContext     = GetProcAddress( hmod, "ImmGetContext"     );
	FARPROC n_ImmGetOpenStatus  = GetProcAddress( hmod, "ImmGetOpenStatus"  );
	FARPROC n_ImmReleaseContext = GetProcAddress( hmod, "ImmReleaseContext" );

	if (
		( n_ImmGetContext    != NULL )
		&&
		( n_ImmGetOpenStatus != NULL )
		&&
		( n_ImmReleaseContext != NULL )
	)
	{

		HIMC himc = (HIMC) n_ImmGetContext( hwnd );

		ret = n_ImmGetOpenStatus( himc );

		n_ImmReleaseContext( hwnd, himc );

	}

	FreeLibrary( hmod );


	return ret;
}


#endif // _H_NONNON_WIN32_WIN_IME

