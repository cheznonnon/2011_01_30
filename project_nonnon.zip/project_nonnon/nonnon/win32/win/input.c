// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_WIN_INPUT
#define _H_NONNON_WIN32_WIN_INPUT




#include "./_debug.c"




inline bool
n_win_is_input_raw( int vk )
{
	return ( false != ( 0x8000 & GetAsyncKeyState( vk ) ) );
}

bool
n_win_is_input( int vk )
{

	if ( vk == VK_LBUTTON )
	{
		if ( GetSystemMetrics( SM_SWAPBUTTON ) ) { vk = VK_RBUTTON; }
	} else
	if ( vk == VK_RBUTTON )
	{
		if ( GetSystemMetrics( SM_SWAPBUTTON ) ) { vk = VK_LBUTTON; }
	}


	return n_win_is_input_raw( vk );
}

void
n_win_input( int vk1, int vk2 )
{

	const int u = KEYEVENTF_KEYUP;


	if ( vk1 ) { keybd_event( vk1, 0, 0, 0 ); }
	if ( vk2 ) { keybd_event( vk2, 0, 0, 0 ); }
	if ( vk1 ) { keybd_event( vk1, 0, u, 0 ); }
	if ( vk2 ) { keybd_event( vk2, 0, u, 0 ); }


	return;
}




#endif // _H_NONNON_WIN32_WIN_INPUT

