// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




#define n_win_txtbox_line_cur(    p    ) ( ( p )->select_cch_y )
#define n_win_txtbox_line_max(    p    ) ( ( p )->txt.sy   )
#define n_win_txtbox_line_scroll( p, y ) n_win_txtbox_scroll( p, ( p )->scroll_pxl_tabbed_x, y )

bool
n_win_txtbox_line_select( n_win_txtbox *p, s32 y )
{

	if ( p == NULL ) { return true; }


	bool ret = false;

//n_win_txtbox_hwndprintf_literal( p, " %d %d ", y, p->txt.sy );

	if ( p->style & N_WIN_TXTBOX_STYLE_LISTBOX )
	{

		if ( p->style_option & N_WIN_TXTBOX_OPTION_LISTBOX_KEEPSEL )
		{

			s32 sy = p->txt.sy;

			if ( ( y < 0 )||( y >= sy ) )
			{

				//

			} else {

				// [Patch] : a caret will move to tail

				p->shift_dragging = VK_RIGHT;

				p->select_cch_x  = 0;
				p->select_cch_sx = n_posix_strlen( n_txt_get( &p->txt, y ) );
				p->select_cch_y  = y;
				p->select_cch_sy = 1;

			}

		} else {
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", y, p->txt.sy );

			if ( ( y < 0 )||( y >= (s32) p->txt.sy ) )
			{

				n_win_txtbox_unselect( p );

				ret = true;

			} else {

				// [Patch] : a caret will move to tail

				p->shift_dragging = VK_RIGHT;

				p->select_cch_x  = 0;
				p->select_cch_sx = n_posix_strlen( n_txt_get( &p->txt, y ) );
				p->select_cch_y  = y;
				p->select_cch_sy = 1;

			}

		}

	} else {

		if ( ( y < 0 )||( y >= (s32) p->txt.sy ) )
		{

			p->select_cch_x  = 0;
			p->select_cch_sx = 0;
			p->select_cch_sy = 0;

			ret = true;

		} else {

			// [Patch] : a caret will move to tail

			p->shift_dragging = VK_RIGHT;

			p->select_cch_x  = 0;
			p->select_cch_sx = n_posix_strlen( n_txt_get( &p->txt, y ) );
			p->select_cch_y  = y;
			p->select_cch_sy = 1;

		}

	}


	return ret;
}

#define N_WIN_TXTBOX_LINE_ADD 0
#define N_WIN_TXTBOX_LINE_MOD 1
#define N_WIN_TXTBOX_LINE_DEL 2
#define N_WIN_TXTBOX_LINE_GET 3
#define N_WIN_TXTBOX_LINE_SET 4
#define N_WIN_TXTBOX_LINE_CAT 5
#define N_WIN_TXTBOX_LINE_CCH 6

#define n_win_txtbox_line_add( p, y, s ) n_win_txtbox_line( p, y, s, N_WIN_TXTBOX_LINE_ADD )
#define n_win_txtbox_line_mod( p, y, s ) n_win_txtbox_line( p, y, s, N_WIN_TXTBOX_LINE_MOD )
#define n_win_txtbox_line_del( p, y    ) n_win_txtbox_line( p, y, 0, N_WIN_TXTBOX_LINE_DEL )
#define n_win_txtbox_line_get( p, y, s ) n_win_txtbox_line( p, y, s, N_WIN_TXTBOX_LINE_GET )
#define n_win_txtbox_line_set( p, y, s ) n_win_txtbox_line( p, y, s, N_WIN_TXTBOX_LINE_SET )
#define n_win_txtbox_line_cat( p, y, s ) n_win_txtbox_line( p, y, s, N_WIN_TXTBOX_LINE_CAT )
#define n_win_txtbox_line_cch( p, y    ) n_win_txtbox_line( p, y, 0, N_WIN_TXTBOX_LINE_CCH )

int
n_win_txtbox_line( n_win_txtbox *p, s32 y, n_posix_char *str, int mode )
{

	if ( p == NULL ) { return 0; }

	if ( n_txt_error( &p->txt ) ) { return 0; }


	if ( mode == N_WIN_TXTBOX_LINE_ADD )
	{
		n_txt_add( &p->txt, y, str );
	} else
	if ( mode == N_WIN_TXTBOX_LINE_MOD )
	{
		n_txt_mod( &p->txt, y, str );
	} else
	if ( mode == N_WIN_TXTBOX_LINE_DEL )
	{
		n_txt_del( &p->txt, y );
	} else
	if ( mode == N_WIN_TXTBOX_LINE_GET )
	{

		if ( str == NULL ) { return 0; } else { n_string_truncate( str ); }

		n_string_copy( n_txt_get( &p->txt, y ), str );

		return 0;

	} else
	if ( mode == N_WIN_TXTBOX_LINE_SET )
	{
		n_txt_set( &p->txt, y, str );
	} else
	if ( mode == N_WIN_TXTBOX_LINE_CAT )
	{

		// [!] : selection only

		if ( y != p->select_cch_y ) { return 0; }


		n_posix_char *line  = n_txt_get( &p->txt, p->select_cch_y );
		s32           cch_f = n_posix_strlen( line );
		s32           cch_t = n_posix_strlen( str  );
		s32           cch   = cch_f + cch_t;
		n_posix_char *s     = n_string_alloccopy( cch, line );


		if ( p->select_cch_sx == N_WIN_TXTBOX_ALL ) { p->select_cch_sx = cch_f; }

		p->select_cch_sx = n_posix_minmax( 0,cch_f, p->select_cch_sx );
		p->select_cch_x  = n_posix_minmax( 0,cch_f, p->select_cch_x  );

//n_posix_debug_literal( "%s : %s", line, str );

		n_posix_sprintf_literal( &s[ p->select_cch_x ], "%s%s", str, &line[ p->select_cch_x + p->select_cch_sx ] );
		n_txt_mod_fast( &p->txt, p->select_cch_y, s );

		//n_memory_free( s );

		extern bool n_win_txtbox_is_caret_tail( n_win_txtbox* );
		if ( false == n_win_txtbox_is_caret_tail( p ) )
		{
			n_win_txtbox_unselect( p );
		}

		p->select_cch_x  = p->select_cch_x + cch_t;
		p->select_cch_sx = 0;

	} else
	if ( mode == N_WIN_TXTBOX_LINE_CCH )
	{

		return n_posix_strlen( n_txt_get( &p->txt, y ) );

	} // else


	//n_win_txtbox_txt_stream( p );
	n_win_txtbox_metrics_maxwidth( p, p->select_cch_y, 1 );


	return 0;
}

n_posix_char*
n_win_txtbox_line_get_new( n_win_txtbox *p, s32 y )
{

	// [!] : n_string_free()/n_string_path_free() a returned string

	size_t        cch = n_win_txtbox_line_cch( p, y );
	n_posix_char *str = n_string_path_new( cch );


	n_win_txtbox_line_get( p, y, str );


	return str;
}


