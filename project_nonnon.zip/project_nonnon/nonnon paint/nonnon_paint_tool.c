// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




// the base layer

#include "../nonnon/win32/win.c"
#include "../nonnon/win32/win_colorpicker.c"
#include "../nonnon/win32/win_iconbutton.c"
#include "../nonnon/win32/win_scrollbar.c"
#include "../nonnon/win32/win_scroller.c"

#include "../nonnon/project/macro.c"




// rc.h

#define H_BTN_00_00  N_PAINT_TOOL_H_BTN_00_00
#define H_BTN_01_00  N_PAINT_TOOL_H_BTN_01_00
#define H_BTN_02_00  N_PAINT_TOOL_H_BTN_02_00
#define H_BTN_03_00  N_PAINT_TOOL_H_BTN_03_00
#define H_BTN_04_00  N_PAINT_TOOL_H_BTN_04_00

#define H_BTN_00_01  N_PAINT_TOOL_H_BTN_00_01
#define H_BTN_01_01  N_PAINT_TOOL_H_BTN_01_01
#define H_BTN_02_01  N_PAINT_TOOL_H_BTN_02_01
#define H_BTN_03_01  N_PAINT_TOOL_H_BTN_03_01
#define H_BTN_04_01  N_PAINT_TOOL_H_BTN_04_01

#define H_BTN_00_02  N_PAINT_TOOL_H_BTN_00_02
#define H_BTN_01_02  N_PAINT_TOOL_H_BTN_01_02
#define H_BTN_02_02  N_PAINT_TOOL_H_BTN_02_02
#define H_BTN_03_02  N_PAINT_TOOL_H_BTN_03_02
#define H_BTN_04_02  N_PAINT_TOOL_H_BTN_04_02


#define H_SCR_SIZE   N_PAINT_TOOL_H_SCR_SIZE
#define H_SCR_MIX    N_PAINT_TOOL_H_SCR_MIX
#define H_SCR_EDGE   N_PAINT_TOOL_H_SCR_EDGE
#define H_SCR_AIR    N_PAINT_TOOL_H_SCR_AIR
#define H_SCR_ZOOM   N_PAINT_TOOL_H_SCR_ZOOM




static HHOOK n_paint_hhook;

LRESULT CALLBACK
n_paint_MouseProc( int nCode, WPARAM wParam, LPARAM lParam )
{

	if ( nCode == HC_ACTION )
	{
//static int i = 0; n_win_hwndprintf_literal( hwnd_main, "%d", i ); i++;

		if ( ( wParam == WM_MOUSEMOVE )||( ( wParam == WM_NCMOUSEMOVE ) ) )
		{

			if ( n_paint_thumbnail_is_on() )
			{
				n_paint_refresh_client();
			}

		}

	}

	return CallNextHookEx( n_paint_hhook, nCode, wParam, lParam );
}

// internal
void
n_paint_tool_filter( int mode )
{

	n_project_pleasewait_on( hwnd_tool );

	n_paint_grabber_filter( mode );

	n_paint_title();

	n_project_pleasewait_off( hwnd_tool );


	return;
}

void
n_paint_hook_init( void )
{

	n_paint_hhook = SetWindowsHookEx( WH_MOUSE, n_paint_MouseProc, GetModuleHandle( NULL ), GetWindowThreadProcessId( hwnd_tool, NULL ) );

	return;
}

void
n_paint_hook_exit( void )
{

	UnhookWindowsHookEx( n_paint_hhook );

	return;
}




void
n_paint_tool_scrollbar_updown( n_win_scroller *p, int delta )
{

	n_win_scrollbar_scroll_unit( &p->scrollbar, p->scrollbar.unit_step * delta, N_WIN_SCROLLBAR_SCROLL_AUTO );
	n_win_scrollbar_draw_always( &p->scrollbar, true );

	return;
}




#define N_PAINY_TOOL_CLIPBOARD_IN  ( 0 )
#define N_PAINY_TOOL_CLIPBOARD_OUT ( 1 )

static int n_paint_tool_clipboard = N_PAINY_TOOL_CLIPBOARD_IN;

void
n_paint_tool_clipboard_switch( int delta )
{

	if ( delta == 0 ) { return; }


	if ( n_paint_tool_clipboard == N_PAINY_TOOL_CLIPBOARD_IN )
	{
		n_paint_tool_clipboard = N_PAINY_TOOL_CLIPBOARD_OUT;
		n_win_icon_add( H_BTN_02_00, NULL, N_APPS_ICON_OFFSET_NONNON_PAINT + 3 );
	} else {
		n_paint_tool_clipboard = N_PAINY_TOOL_CLIPBOARD_IN;
		n_win_icon_add( H_BTN_02_00, NULL, N_APPS_ICON_OFFSET_NONNON_PAINT + 2 );
	}


	return;
}

#ifndef _WIN64
static WNDPROC n_paint_tool_clipboard_pfunc;
#endif // #ifndef _WIN64

LRESULT CALLBACK
#ifdef _WIN64
n_paint_tool_clipboard_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData )
#else  // #ifdef _WIN64
n_paint_tool_clipboard_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
#endif // #ifdef _WIN64
{

	switch( msg ) {


	case WM_RBUTTONDOWN   :
	case WM_RBUTTONDBLCLK :

		n_paint_tool_clipboard_switch( 1 );

	break;


	} // switch()


#ifdef _WIN64
	return DefSubclassProc( hwnd, msg, wparam, lparam );
#else  // #ifdef _WIN64
	return CallWindowProc( n_paint_tool_clipboard_pfunc, hwnd, msg, wparam, lparam );
#endif // #ifdef _WIN64
}




void
n_paint_tool_saveicon_refresh( bool refresh_onoff )
{

	if ( n_paint_format_is_bmp( n_paint_bmpname ) )
	{
		n_win_icon_add( H_BTN_04_00, NULL, N_APPS_ICON_OFFSET_NONNON_PAINT +  5 );
		n_paint_format = N_PAINT_FORMAT_BMP;
	} else
	if ( n_paint_format_is_ico( n_paint_bmpname ) )
	{
		n_win_icon_add( H_BTN_04_00, NULL, N_APPS_ICON_OFFSET_NONNON_PAINT +  6 );
		n_paint_format = N_PAINT_FORMAT_ICO;
	} else
	if ( n_paint_format_is_cur( n_paint_bmpname ) )
	{
		n_win_icon_add( H_BTN_04_00, NULL, N_APPS_ICON_OFFSET_NONNON_PAINT +  7 );
		n_paint_format = N_PAINT_FORMAT_CUR;
	} else
	if ( n_paint_format_is_jpg( n_paint_bmpname ) )
	{
		n_win_icon_add( H_BTN_04_00, NULL, N_APPS_ICON_OFFSET_NONNON_PAINT +  8 );
		n_paint_format = N_PAINT_FORMAT_JPG;
	} else
	if ( n_paint_format_is_png( n_paint_bmpname ) )
	{
		n_win_icon_add( H_BTN_04_00, NULL, N_APPS_ICON_OFFSET_NONNON_PAINT +  9 );
		n_paint_format = N_PAINT_FORMAT_PNG;
	} else
	if ( n_paint_format_is_lyr( n_paint_bmpname ) )
	{
		n_win_icon_add( H_BTN_04_00, NULL, N_APPS_ICON_OFFSET_NONNON_PAINT + 10 );
		n_paint_format = N_PAINT_FORMAT_LYR;
	}


	//if ( refresh_onoff ) { n_paint_refresh_client(); }


	return;
}

void
n_paint_tool_saveicon_switch( int delta )
{

	if ( delta == 0 ) { return; }

	if ( delta >= 1 )
	{
		if ( n_paint_format_is_bmp( n_paint_bmpname ) ) { n_string_path_ext_mod( N_PAINT_EXT_ICO, n_paint_bmpname ); } else
		if ( n_paint_format_is_ico( n_paint_bmpname ) ) { n_string_path_ext_mod( N_PAINT_EXT_CUR, n_paint_bmpname ); } else
		if ( n_paint_format_is_cur( n_paint_bmpname ) ) { n_string_path_ext_mod( N_PAINT_EXT_JPG, n_paint_bmpname ); } else
		if ( n_paint_format_is_jpg( n_paint_bmpname ) ) { n_string_path_ext_mod( N_PAINT_EXT_PNG, n_paint_bmpname ); } else
		if ( n_paint_format_is_png( n_paint_bmpname ) ) { n_string_path_ext_mod( N_PAINT_EXT_LYR, n_paint_bmpname ); } else
		if ( n_paint_format_is_lyr( n_paint_bmpname ) ) { n_string_path_ext_mod( N_PAINT_EXT_BMP, n_paint_bmpname ); }
	} else {
		if ( n_paint_format_is_bmp( n_paint_bmpname ) ) { n_string_path_ext_mod( N_PAINT_EXT_LYR, n_paint_bmpname ); } else
		if ( n_paint_format_is_ico( n_paint_bmpname ) ) { n_string_path_ext_mod( N_PAINT_EXT_BMP, n_paint_bmpname ); } else
		if ( n_paint_format_is_cur( n_paint_bmpname ) ) { n_string_path_ext_mod( N_PAINT_EXT_ICO, n_paint_bmpname ); } else
		if ( n_paint_format_is_jpg( n_paint_bmpname ) ) { n_string_path_ext_mod( N_PAINT_EXT_CUR, n_paint_bmpname ); } else
		if ( n_paint_format_is_png( n_paint_bmpname ) ) { n_string_path_ext_mod( N_PAINT_EXT_JPG, n_paint_bmpname ); } else
		if ( n_paint_format_is_lyr( n_paint_bmpname ) ) { n_string_path_ext_mod( N_PAINT_EXT_PNG, n_paint_bmpname ); }
	}

	n_paint_tool_saveicon_refresh( true );

	n_paint_title();


	return;
}

#ifndef _WIN64
static WNDPROC n_paint_tool_savebutton_pfunc;
#endif // #ifndef _WIN64

LRESULT CALLBACK
#ifdef _WIN64
n_paint_tool_savebutton_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData )
#else  // #ifdef _WIN64
n_paint_tool_savebutton_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
#endif // #ifdef _WIN64
{

	switch( msg ) {


	case WM_RBUTTONDOWN   :
	case WM_RBUTTONDBLCLK :

		n_paint_tool_saveicon_switch( 1 );

	break;


	} // switch()


#ifdef _WIN64
	return DefSubclassProc( hwnd, msg, wparam, lparam );
#else  // #ifdef _WIN64
	return CallWindowProc( n_paint_tool_savebutton_pfunc, hwnd, msg, wparam, lparam );
#endif // #ifdef _WIN64
}




void
n_paint_tool_exit( void )
{

	n_win_scroller_exit( H_SCR_SIZE );
	n_win_scroller_exit( H_SCR_MIX  );
	n_win_scroller_exit( H_SCR_EDGE );
	n_win_scroller_exit( H_SCR_AIR  );
	n_win_scroller_exit( H_SCR_ZOOM );

	n_win_iconbutton_exit( hwnd_tool, H_BTN_00_00 );
	n_win_iconbutton_exit( hwnd_tool, H_BTN_01_00 );
	n_win_iconbutton_exit( hwnd_tool, H_BTN_02_00 );
	n_win_iconbutton_exit( hwnd_tool, H_BTN_03_00 );
	n_win_iconbutton_exit( hwnd_tool, H_BTN_04_00 );

	n_win_iconbutton_exit( hwnd_tool, H_BTN_00_01 );
	n_win_iconbutton_exit( hwnd_tool, H_BTN_01_01 );
	n_win_iconbutton_exit( hwnd_tool, H_BTN_02_01 );
	n_win_iconbutton_exit( hwnd_tool, H_BTN_03_01 );
	n_win_iconbutton_exit( hwnd_tool, H_BTN_04_01 );

	n_win_iconbutton_exit( hwnd_tool, H_BTN_00_02 );
	n_win_iconbutton_exit( hwnd_tool, H_BTN_01_02 );
	n_win_iconbutton_exit( hwnd_tool, H_BTN_02_02 );
	n_win_iconbutton_exit( hwnd_tool, H_BTN_03_02 );
	n_win_iconbutton_exit( hwnd_tool, H_BTN_04_02 );

	n_win_colorpicker_exit( &cp );

	n_win_stdfont_exit( n_paint_tool_hgui, N_PAINT_TOOL_GUI_MAX );


	n_paint_hook_exit();


#ifdef _WIN64
		RemoveWindowSubclass( H_BTN_02_00, n_paint_tool_clipboard_subclass , 0 );
		RemoveWindowSubclass( H_BTN_04_00, n_paint_tool_savebutton_subclass, 0 );
#else  // #ifdef _WIN64
		n_win_gui_subclass_set( H_BTN_02_00, n_paint_tool_clipboard_pfunc  );
		n_win_gui_subclass_set( H_BTN_04_00, n_paint_tool_savebutton_pfunc );
#endif // #ifdef _WIN64


	return;
}

// internal
void
n_paint_tool_iconbutton_toolswitch( int line )
{

	static int prev = -1;

	if ( line == -1 )
	{
		if ( prev == 1 ) { line = 2; } else { line = 1; }
	}

	if ( line == 1 )
	{

		ShowWindow( H_BTN_00_02, SW_HIDE );
		ShowWindow( H_BTN_01_02, SW_HIDE );
		ShowWindow( H_BTN_02_02, SW_HIDE );
		ShowWindow( H_BTN_03_02, SW_HIDE );
		ShowWindow( H_BTN_04_02, SW_HIDE );

		ShowWindow( H_BTN_00_01, SW_NORMAL );
		ShowWindow( H_BTN_01_01, SW_NORMAL );
		ShowWindow( H_BTN_02_01, SW_NORMAL );
		ShowWindow( H_BTN_03_01, SW_HIDE   );
		ShowWindow( H_BTN_04_01, SW_NORMAL );

	} else
	if ( line == 2 )
	{

		ShowWindow( H_BTN_00_01, SW_HIDE );
		ShowWindow( H_BTN_01_01, SW_HIDE );
		ShowWindow( H_BTN_02_01, SW_HIDE );
		ShowWindow( H_BTN_03_01, SW_HIDE );
		ShowWindow( H_BTN_04_01, SW_HIDE );

		ShowWindow( H_BTN_00_02, SW_NORMAL );
		ShowWindow( H_BTN_01_02, SW_NORMAL );
		ShowWindow( H_BTN_02_02, SW_NORMAL );
		ShowWindow( H_BTN_03_02, SW_NORMAL );
		ShowWindow( H_BTN_04_02, SW_NORMAL );

	}

	prev = line;


	return;
}

// internal
void
n_paint_tool_iconbutton_grabber_onoff( bool onoff )
{

	if ( onoff )
	{

		n_paint_tool_grabber_onoff( true );


		nwscr_enable( H_SCR_SIZE,  false );
		nwscr_enable( H_SCR_MIX,   false );
		nwscr_enable( H_SCR_EDGE,  false );
		nwscr_enable( H_SCR_AIR,   false );
		nwclr_enable( &cp,         false );

		EnableWindow( H_BTN_02_00,  true );
		EnableWindow( H_BTN_04_00, false );
		EnableWindow( H_BTN_04_01, false );

	} else {

		if ( N_PAINT_GRABBER_IS_NEUTRAL() )
		{
			n_paint_tool_grabber_onoff      ( false );
			//n_paint_tool_grabber_trans_onoff( false );
		}


		nwscr_enable( H_SCR_SIZE,  true );
		nwscr_enable( H_SCR_MIX,   true );
		nwscr_enable( H_SCR_EDGE,  true );
		nwscr_enable( H_SCR_AIR,   true );
		nwclr_enable( &cp,         true );

		EnableWindow( H_BTN_02_00, N_PAINT_GRABBER_IS_NEUTRAL() );
		EnableWindow( H_BTN_04_00, N_PAINT_GRABBER_IS_NEUTRAL() );
		EnableWindow( H_BTN_04_01, true );

		n_win_icon_add( H_BTN_02_01, NULL, N_APPS_ICON_OFFSET_NONNON_PAINT + 13 );

	}

}

// internal
void
n_paint_tool_iconbutton_pentype( int type )
{

	// [!] : reset

	n_win_style_del( H_BTN_00_01, BS_PUSHLIKE );
	n_win_style_del( H_BTN_01_01, BS_PUSHLIKE );
	n_win_style_del( H_BTN_02_01, BS_PUSHLIKE );
	//n_win_style_del( H_BTN_03_01, BS_PUSHLIKE );
	//n_win_style_del( H_BTN_04_01, BS_PUSHLIKE );

	n_win_refresh( H_BTN_00_01, false );
	n_win_refresh( H_BTN_01_01, false );
	n_win_refresh( H_BTN_02_01, false );
	//n_win_refresh( H_BTN_03_01, false );
	//n_win_refresh( H_BTN_04_01, false );


	if ( type == N_PAINT_TOOL_TYPE_PEN  )
	{

		if ( tooltype == N_PAINT_TOOL_TYPE_GRAB )
		{
			n_paint_tool_iconbutton_grabber_onoff( false );
		}

		n_win_cursor_add_literal( hwnd_main, "NONNON_PAINT_PEN" );

		n_win_style_add( H_BTN_00_01, BS_PUSHLIKE );

	} else
	if ( type == N_PAINT_TOOL_TYPE_FILL )
	{

		if ( tooltype == N_PAINT_TOOL_TYPE_GRAB )
		{
			n_paint_tool_iconbutton_grabber_onoff( false );
		}

		n_win_cursor_add_literal( hwnd_main, "NONNON_PAINT_FILL" );

		n_win_style_add( H_BTN_01_01, BS_PUSHLIKE );

	} else
	if ( type == N_PAINT_TOOL_TYPE_GRAB )
	{

		if ( tooltype != N_PAINT_TOOL_TYPE_GRAB )
		{
			n_paint_tool_iconbutton_grabber_onoff( true );
		}

		n_win_cursor_add( hwnd_main, IDC_ARROW );

		n_project_system_icon_color_special_onoff =  true;
		n_win_icon_add( H_BTN_02_01, NULL, N_APPS_ICON_OFFSET_NONNON_PAINT + 14 );
		n_project_system_icon_color_special_onoff = false;

		n_paint_grabber_status();

		n_paint_layer_grabber_onoff( true );

	}// else


	tooltype = type;


	return;
}

// internal
void
n_paint_tool_resize( int nwinset )
{

	const bool redraw = false;


	s32 ctl,ico,m; n_win_stdsize( hwnd_tool, &ctl, &ico, &m );


	s32 gap = m * 2;
	s32 csx = ( ico * 5 ) +               ( gap * 4 );
	s32 csy = ( ctl * 9 ) + ( ico * 2 ) + ( gap * 2 );// + ( gap / 2 );

	if ( nwin_tool.posx == -1 ) { nwin_tool.posx = (double) n_paint_desktop_sx * 0.1; }
	if ( nwin_tool.posy == -1 ) { nwin_tool.posy = (double) n_paint_desktop_sy * 0.1; }

#ifdef _MSC_VER

	//

#else  // #ifdef _MSC_VER

	// [!] : MinGW version only

	if ( n_win_dwm_is_on() )
	{
		static bool init_onoff = false;
		if ( init_onoff == false )
		{
			init_onoff = true;

			nwin_tool.posx += 5;
			nwin_tool.posy += 5;
		}
	}

#endif // #ifdef _MSC_VER

	n_win_set( hwnd_tool, &nwin_tool, csx + m, csy + m, nwinset );


	// [!] : scrollers

	n_win_scroller_move( H_SCR_SIZE,  0, 0*ctl, csx,ctl, redraw );
	n_win_scroller_move( H_SCR_MIX,   0, 1*ctl, csx,ctl, redraw );
	n_win_scroller_move( H_SCR_EDGE,  0, 2*ctl, csx,ctl, redraw );
	n_win_scroller_move( H_SCR_AIR,   0, 3*ctl, csx,ctl, redraw );
	n_win_scroller_move( H_SCR_ZOOM,  0, 4*ctl, csx,ctl, redraw );


	s32 y = 0;


	// [!] : color picker

	y = ( ctl * 4 );

	n_win_colorpicker_move( &cp,  0, 5*ctl, csx,y, false );


	// [!] : icon buttons

	y = ( ctl * 9 ) + ( gap * 1 );

	n_win_move( H_BTN_00_00, (ico*0)+(gap*0),        y, ico,ico, redraw );
	// Reserved
	n_win_move( H_BTN_02_00, (ico*2)+(gap*2),        y, ico,ico, redraw );
	n_win_move( H_BTN_03_00, (ico*3)+(gap*3),        y, ico,ico, redraw );
	n_win_move( H_BTN_04_00, (ico*4)+(gap*4),        y, ico,ico, redraw );

	y = ( ctl * 9 ) + ( gap * 2 );

	n_win_move( H_BTN_00_01, (ico*0)+(gap*0),(ico*1)+y, ico,ico, redraw );
	n_win_move( H_BTN_01_01, (ico*1)+(gap*1),(ico*1)+y, ico,ico, redraw );
	n_win_move( H_BTN_02_01, (ico*2)+(gap*2),(ico*1)+y, ico,ico, redraw );
	n_win_move( H_BTN_03_01, (ico*3)+(gap*3),(ico*1)+y, ico,ico, redraw );
	n_win_move( H_BTN_04_01, (ico*4)+(gap*4),(ico*1)+y, ico,ico, redraw );

	n_win_move( H_BTN_00_02, (ico*0)+(gap*0),(ico*1)+y, ico,ico, redraw );
	n_win_move( H_BTN_01_02, (ico*1)+(gap*1),(ico*1)+y, ico,ico, redraw );
	n_win_move( H_BTN_02_02, (ico*2)+(gap*2),(ico*1)+y, ico,ico, redraw );
	n_win_move( H_BTN_03_02, (ico*3)+(gap*3),(ico*1)+y, ico,ico, redraw );
	n_win_move( H_BTN_04_02, (ico*4)+(gap*4),(ico*1)+y, ico,ico, redraw );


	return;
}

void
n_paint_tool_icon_add( void )
{

	n_win_icon_add( H_BTN_00_00, NULL, N_APPS_ICON_OFFSET_NONNON_PAINT +  1 );
	//n_win_icon_add( H_BTN_01_00, NULL,  N_APPS_ICON_OFFSET_NONNON_PAINT + 0 );
	n_win_icon_add( H_BTN_02_00, NULL, N_APPS_ICON_OFFSET_NONNON_PAINT +  2 );
	n_win_icon_add( H_BTN_03_00, NULL, N_APPS_ICON_OFFSET_NONNON_PAINT +  4 );
	//n_win_icon_add( H_BTN_04_00, NULL, N_APPS_ICON_OFFSET_NONNON_PAINT +  0 );

	n_win_icon_add( H_BTN_00_01, NULL, N_APPS_ICON_OFFSET_NONNON_PAINT + 11 );
	n_win_icon_add( H_BTN_01_01, NULL, N_APPS_ICON_OFFSET_NONNON_PAINT + 12 );
	n_win_icon_add( H_BTN_02_01, NULL, N_APPS_ICON_OFFSET_NONNON_PAINT + 13 );
	//n_win_icon_add( H_BTN_03_01, NULL, N_APPS_ICON_OFFSET_NONNON_PAINT + 0 );
	n_win_icon_add( H_BTN_04_01, NULL, N_APPS_ICON_OFFSET_NONNON_PAINT + 15 );

	n_win_icon_add( H_BTN_00_02, NULL, N_APPS_ICON_OFFSET_NONNON_PAINT + 16 );
	n_win_icon_add( H_BTN_01_02, NULL, N_APPS_ICON_OFFSET_NONNON_PAINT + 17 );
	n_win_icon_add( H_BTN_02_02, NULL, N_APPS_ICON_OFFSET_NONNON_PAINT + 18 );
	n_win_icon_add( H_BTN_03_02, NULL, N_APPS_ICON_OFFSET_NONNON_PAINT + 19 );
	n_win_icon_add( H_BTN_04_02, NULL, N_APPS_ICON_OFFSET_NONNON_PAINT + 20 );


	return;
}

void
n_paint_tool_on_settingchange( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static UINT timer_id = 0;


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		if ( timer_id == 0 ) { timer_id = n_win_timer_id_get(); }

		n_win_timer_init( hwnd, timer_id, n_project_settingchange_interval() );

	break;


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam != timer_id ) { break; }


		n_win_timer_exit( hwnd, timer_id );


		n_project_darkmode();

		n_win_init_background( hwnd );
		n_win_refresh( hwnd, true );

		n_paint_tool_icon_add();

		n_win_iconbutton_on_settingchange( hwnd, msg, wparam, lparam, H_BTN_00_00 );
		n_win_iconbutton_on_settingchange( hwnd, msg, wparam, lparam, H_BTN_01_00 );
		n_win_iconbutton_on_settingchange( hwnd, msg, wparam, lparam, H_BTN_02_00 );
		n_win_iconbutton_on_settingchange( hwnd, msg, wparam, lparam, H_BTN_03_00 );
		n_win_iconbutton_on_settingchange( hwnd, msg, wparam, lparam, H_BTN_04_00 );

		n_win_iconbutton_on_settingchange( hwnd, msg, wparam, lparam, H_BTN_00_01 );
		n_win_iconbutton_on_settingchange( hwnd, msg, wparam, lparam, H_BTN_01_01 );
		n_win_iconbutton_on_settingchange( hwnd, msg, wparam, lparam, H_BTN_02_01 );
		n_win_iconbutton_on_settingchange( hwnd, msg, wparam, lparam, H_BTN_03_01 );
		n_win_iconbutton_on_settingchange( hwnd, msg, wparam, lparam, H_BTN_04_01 );

		n_win_iconbutton_on_settingchange( hwnd, msg, wparam, lparam, H_BTN_00_02 );
		n_win_iconbutton_on_settingchange( hwnd, msg, wparam, lparam, H_BTN_01_02 );
		n_win_iconbutton_on_settingchange( hwnd, msg, wparam, lparam, H_BTN_02_02 );
		n_win_iconbutton_on_settingchange( hwnd, msg, wparam, lparam, H_BTN_03_02 );
		n_win_iconbutton_on_settingchange( hwnd, msg, wparam, lparam, H_BTN_04_02 );

		n_win_stdfont_init( n_paint_tool_hgui, N_PAINT_TOOL_GUI_MAX );

		n_paint_tool_resize( N_WIN_SET_DEFAULT );

		n_win_scroller_on_settingchange( H_SCR_SIZE );
		n_win_scroller_on_settingchange( H_SCR_MIX  );
		n_win_scroller_on_settingchange( H_SCR_EDGE );
		n_win_scroller_on_settingchange( H_SCR_AIR  );
		n_win_scroller_on_settingchange( H_SCR_ZOOM );

		n_win_colorpicker_on_settingchange( &cp );

	break;


	} // switch


}

LRESULT CALLBACK
n_paint_tool_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static bool scr_init_onoff = true;


	n_win_simplemenu_xmouse( &n_paint_simplemenu, hwnd, msg );


	n_paint_tool_on_settingchange( hwnd, msg, wparam, lparam );


	switch( msg ) {


	case WM_CREATE :


		// Global

		n_project_darkmode();

		n_win_ime_disable( hwnd );

		n_win_scroller_zero( H_SCR_SIZE );
		n_win_scroller_zero( H_SCR_MIX  );
		n_win_scroller_zero( H_SCR_EDGE );
		n_win_scroller_zero( H_SCR_AIR  );
		n_win_scroller_zero( H_SCR_ZOOM );


		// [Needed]
		//
		//	don't rely on n_win_gui()/CreateWindow()'s return value

		hwnd_tool = hwnd;
		tooltype  = N_PAINT_TOOL_TYPE_PEN;


		// Window

		n_win_init_literal( hwnd, N_PAINT_APPNAME, "", "" );


		n_win_scroller_init_literal( H_SCR_SIZE, hwnd, "Size" );
		n_win_scroller_init_literal( H_SCR_MIX , hwnd, "Mix"  );
		n_win_scroller_init_literal( H_SCR_EDGE, hwnd, "Edge" );
		n_win_scroller_init_literal( H_SCR_AIR , hwnd, "Air"  );
		n_win_scroller_init_literal( H_SCR_ZOOM, hwnd, "Zoom" );

		n_win_colorpicker_init( &cp, hwnd );

		n_win_gui_literal( hwnd, FICOBTN, "", &H_BTN_00_00 );
		n_win_gui_literal( hwnd, FICOBTN, "", &H_BTN_01_00 );
		n_win_gui_literal( hwnd, FICOBTN, "", &H_BTN_02_00 );
		n_win_gui_literal( hwnd, FICOBTN, "", &H_BTN_03_00 );
		n_win_gui_literal( hwnd, FICOBTN, "", &H_BTN_04_00 );

		n_win_gui_literal( hwnd, FICOBTN, "", &H_BTN_00_01 );
		n_win_gui_literal( hwnd, FICOBTN, "", &H_BTN_01_01 );
		n_win_gui_literal( hwnd, FICOBTN, "", &H_BTN_02_01 );
		n_win_gui_literal( hwnd, FICOBTN, "", &H_BTN_03_01 );
		n_win_gui_literal( hwnd, FICOBTN, "", &H_BTN_04_01 );

		n_win_gui_literal( hwnd, FICOBTN, "", &H_BTN_00_02 );
		n_win_gui_literal( hwnd, FICOBTN, "", &H_BTN_01_02 );
		n_win_gui_literal( hwnd, FICOBTN, "", &H_BTN_02_02 );
		n_win_gui_literal( hwnd, FICOBTN, "", &H_BTN_03_02 );
		n_win_gui_literal( hwnd, FICOBTN, "", &H_BTN_04_02 );


		n_paint_tool_icon_add();


		// Style

		n_win_style_new( hwnd, WS_POPUP | WS_CAPTION );

#ifdef _WIN64
		SetWindowSubclass( H_BTN_02_00, n_paint_tool_clipboard_subclass, 0, 0 );
#else  // #ifdef _WIN64
		n_paint_tool_clipboard_pfunc = n_win_gui_subclass_set( H_BTN_02_00, n_paint_tool_clipboard_subclass );
#endif // #ifdef _WIN64

#ifdef _WIN64
		SetWindowSubclass( H_BTN_04_00, n_paint_tool_savebutton_subclass, 0, 0 );
#else  // #ifdef _WIN64
		n_paint_tool_savebutton_pfunc = n_win_gui_subclass_set( H_BTN_04_00, n_paint_tool_savebutton_subclass );
#endif // #ifdef _WIN64

		n_win_iconbutton_init( hwnd, H_BTN_00_00 );
		n_win_iconbutton_init( hwnd, H_BTN_01_00 );
		n_win_iconbutton_init( hwnd, H_BTN_02_00 );
		n_win_iconbutton_init( hwnd, H_BTN_03_00 );
		n_win_iconbutton_init( hwnd, H_BTN_04_00 );

		n_win_iconbutton_init( hwnd, H_BTN_00_01 );
		n_win_iconbutton_init( hwnd, H_BTN_01_01 );
		n_win_iconbutton_init( hwnd, H_BTN_02_01 );
		n_win_iconbutton_init( hwnd, H_BTN_03_01 );
		n_win_iconbutton_init( hwnd, H_BTN_04_01 );

		n_win_iconbutton_init( hwnd, H_BTN_00_02 );
		n_win_iconbutton_init( hwnd, H_BTN_01_02 );
		n_win_iconbutton_init( hwnd, H_BTN_02_02 );
		n_win_iconbutton_init( hwnd, H_BTN_03_02 );
		n_win_iconbutton_init( hwnd, H_BTN_04_02 );


		// [!] : unused

		ShowWindow( H_BTN_01_00, SW_HIDE );
		ShowWindow( H_BTN_03_01, SW_HIDE );


		n_paint_hook_init();


		// Size

		n_win_stdfont_init( n_paint_tool_hgui, N_PAINT_TOOL_GUI_MAX );


		// [Needed] : before n_paint_tool_resize()

//n_win_scrollbar_debug_instance = &H_SCR_SIZE->scrollbar;

		n_win_scroller_scroll_parameter( H_SCR_SIZE, 1,  5,               50, pensize, true );
		n_win_scroller_scroll_parameter( H_SCR_EDGE, 1, 10,              100, edge   , true );
		n_win_scroller_scroll_parameter( H_SCR_MIX , 1, 10,              100, mix    , true );
		n_win_scroller_scroll_parameter( H_SCR_AIR , 1, 10,              255, air    , true );
		n_win_scroller_scroll_parameter( H_SCR_ZOOM, 1, 10, N_PAINT_ZOOM_MAX, zoom   , true );

		n_win_colorpicker_refresh( &cp, cp.a, cp.r, cp.g, cp.b );

		scr_init_onoff = false;


		n_paint_tool_resize( N_WIN_SET_NEEDPOS | N_WIN_SET_INNERPOS );


		// Init

		n_paint_tool_iconbutton_toolswitch( 1 );

		n_paint_tool_iconbutton_pentype( tooltype );


		// Display

		ShowWindowAsync( hwnd, SW_HIDE );

	break;


	case WM_NCLBUTTONDOWN :
	case WM_LBUTTONDOWN   :

		SetFocus( hwnd );

	break;


	case WM_COMMAND :
	{

		HWND h = (HWND) lparam;


		if ( h == H_BTN_00_00 )
		{
			n_paint_tool_iconbutton_toolswitch( -1 );
		} else
		if ( h == H_BTN_01_00 )
		{
			//
		} else
		if ( h == H_BTN_02_00 )
		{

			if ( n_paint_tool_clipboard == N_PAINY_TOOL_CLIPBOARD_IN )
			{
				n_paint_grabber_clipboard();
			} else {
				if ( n_paint_layer_onoff )
				{
					int y = n_paint_layer_txtbox.select_cch_y;

					if ( N_PAINT_GRABBER_IS_DRAG_OK() )
					{
						n_clipboard_nbmp_set( &n_paint_layer_data[ y ].bmp_grab );
					} else {
						n_clipboard_nbmp_set( &n_paint_layer_data[ y ].bmp_data );
					}
				} else {
					if ( N_PAINT_GRABBER_IS_DRAG_OK() )
					{
						n_clipboard_nbmp_set( n_paint_bmp_grab );
					} else {
						n_clipboard_nbmp_set( n_paint_bmp_data );
					}
				}
			}

		} else
		if ( h == H_BTN_03_00 )
		{
			n_win_gui( hwnd_main, WINDOW, n_paint_resizer_wndproc, &n_paint_hpopup );
		} else
		if ( h == H_BTN_04_00 )
		{
			n_paint_formatter_name = n_paint_bmpname;
			if ( n_paint_layer_onoff == false )
			{
				n_paint_formatter_bmp =  n_paint_bmp_data;
			} else {
				s32 bmpsx = N_BMP_SX( &n_paint_layer_data[ 0 ].bmp_data );
				s32 bmpsy = N_BMP_SY( &n_paint_layer_data[ 0 ].bmp_data );

				n_bmp_new( &n_paint_layer_as_one, bmpsx, bmpsy );
				n_bmp_layercopy( n_paint_layer_data, &n_paint_layer_as_one, 0,0,bmpsx,bmpsy, 0,0, false );

				n_paint_formatter_bmp = &n_paint_layer_as_one;
			}
			n_win_gui( hwnd_main, WINDOW, n_paint_formatter_wndproc, &n_paint_hpopup );
		} else

		if ( h == H_BTN_00_01 )
		{
			n_paint_tool_iconbutton_pentype( N_PAINT_TOOL_TYPE_PEN );
		} else
		if ( h == H_BTN_01_01 )
		{
			n_paint_tool_iconbutton_pentype( N_PAINT_TOOL_TYPE_FILL );
		} else
		if ( h == H_BTN_02_01 )
		{
			if ( tooltype == N_PAINT_TOOL_TYPE_GRAB ) { n_paint_grabber_reset(); }
			n_paint_tool_iconbutton_pentype( N_PAINT_TOOL_TYPE_GRAB );
		} else
		if ( h == H_BTN_03_01 )
		{
			//
		} else
		if ( h == H_BTN_04_01 )
		{
			n_win_gui( hwnd_main, WINDOW, n_paint_colorhistory_wndproc, &n_paint_hpopup );
		} else

		if ( h == H_BTN_00_02 )
		{
			n_paint_tool_filter( N_PAINT_FILTER_SCALE_LIL );
		} else
		if ( h == H_BTN_01_02 )
		{
			n_paint_tool_filter( N_PAINT_FILTER_SCALE_BIG );
		} else
		if ( h == H_BTN_02_02 )
		{
			n_paint_tool_filter( N_PAINT_FILTER_MIRROR );
		} else
		if ( h == H_BTN_03_02 )
		{
			n_paint_tool_filter( N_PAINT_FILTER_ROTATE_L );
		} else
		if ( h == H_BTN_04_02 )
		{
			n_paint_tool_filter( N_PAINT_FILTER_ROTATE_R );
		} else

		if ( h == n_win_scroller_scroll_hwnd( H_SCR_SIZE ) )
		{

			if ( scr_init_onoff == false ) { pensize = wparam; }

			n_win_hwndprintf_literal( H_SCR_SIZE->value, "%3d", n_paint_pensize() );

		} else

		if ( h == n_win_scroller_scroll_hwnd( H_SCR_MIX ) )
		{

			if ( scr_init_onoff == false ) { mix = wparam; }

			n_win_hwndprintf_literal( H_SCR_MIX->value, "%3d", mix );

		} else

		if ( h == n_win_scroller_scroll_hwnd( H_SCR_EDGE ) )
		{

			if ( scr_init_onoff == false ) { edge = wparam; }

			n_win_hwndprintf_literal( H_SCR_EDGE->value, "%3d", edge );

		} else

		if ( h == n_win_scroller_scroll_hwnd( H_SCR_AIR ) )
		{

			if ( scr_init_onoff == false ) { air = wparam; }

			n_win_hwndprintf_literal( H_SCR_AIR->value, "%3d", air );

		} else

		if ( h == n_win_scroller_scroll_hwnd( H_SCR_ZOOM ) )
		{
//n_posix_debug_literal( " %d %d ", wparam, zoom );

			if ( scr_init_onoff != false )
			{
				if ( n_paint_is_zoom_in( zoom ) )
				{
					n_win_hwndprintf_literal( H_SCR_ZOOM->value,  "%3d", n_paint_zoom_get( zoom ) );
				} else {
					n_win_hwndprintf_literal( H_SCR_ZOOM->value, "1/%d", n_paint_zoom_get( zoom ) );
				}

				break;
			}


			static int prev = N_PAINT_ZOOM_ZERO + 1;

			zoom = n_paint_zoom_clamp( zoom, wparam );
			H_SCR_ZOOM->scrollbar.unit_pos = zoom;

			if ( n_paint_is_zoom_in( zoom ) )
			{
				n_win_hwndprintf_literal( H_SCR_ZOOM->value,  "%3d", n_paint_zoom_get( zoom ) );
			} else {
				n_win_hwndprintf_literal( H_SCR_ZOOM->value, "1/%d", n_paint_zoom_get( zoom ) );
			}


			// [!] : restore scroll position

			s32 ox = nwin_main.csx / 2;
			s32 oy = nwin_main.csy / 2;

			if ( hwnd_main == n_win_cursor2hwnd() )
			{
				n_win_cursor_position_relative( hwnd_main, &ox, &oy );
			}

			nwin_main.scrollx += ox;
			nwin_main.scrolly += oy;

			if ( ( n_paint_is_zoom_in( zoom ) )&&( n_paint_is_zoom_in( prev ) ) )
			{
				nwin_main.scrollx /= n_paint_zoom_get( prev );
				nwin_main.scrolly /= n_paint_zoom_get( prev );
			} else {
				nwin_main.scrollx *= n_paint_zoom_get( prev );
				nwin_main.scrolly *= n_paint_zoom_get( prev );
			}

			nwin_main.scrollx += nwin_main.scrollx % 2;
			nwin_main.scrolly += nwin_main.scrolly % 2;

			if ( ( n_paint_is_zoom_in( zoom ) )&&( n_paint_is_zoom_in( prev ) ) )
			{
				nwin_main.scrollx *= n_paint_zoom_get( zoom );
				nwin_main.scrolly *= n_paint_zoom_get( zoom );
			} else {
				nwin_main.scrollx /= n_paint_zoom_get( zoom );
				nwin_main.scrolly /= n_paint_zoom_get( zoom );
			}

			nwin_main.scrollx -= ox;
			nwin_main.scrolly -= oy;

			n_paint_hscr.unit_pos = nwin_main.scrollx;
			n_paint_vscr.unit_pos = nwin_main.scrolly;


			prev = zoom;


			//n_paint_refresh_window_id( N_PAINT_REFRESH_ID_ZOOM );

			n_paint_refresh_combine = N_PAINT_REFRESH_WINDOW;
			n_win_refresh( hwnd_main, false );

		}

	}
	break;


	case WM_SETFOCUS :

		n_paint_status();

	break;


	case WM_MOUSEWHEEL :

		if ( H_BTN_02_00 == n_win_cursor2hwnd() )
		{

			int delta = n_win_scrollbar_wheeldelta( wparam, 1, false );
//n_win_hwndprintf_literal( hwnd_tool, " %d ", delta );

			n_paint_tool_clipboard_switch( delta );

		} else
		if ( H_BTN_04_00 == n_win_cursor2hwnd() )
		{

			int delta = n_win_scrollbar_wheeldelta( wparam, 1, false );
//n_win_hwndprintf_literal( hwnd_tool, " %d ", delta );

			n_paint_tool_saveicon_switch( delta );

		}

	break;


	case WM_CLOSE :

		// [!] : for Alt + F4

		return 0;

	break;


	} // switch()


	{
		LRESULT ret = n_win_darkmode_proc( hwnd, msg, wparam, lparam );
		if ( ret ) { return ret; }
	}


	if ( scr_init_onoff == false )
	{
		n_win_scroller_proc( hwnd, msg, wparam, lparam, H_SCR_SIZE );
		n_win_scroller_proc( hwnd, msg, wparam, lparam, H_SCR_MIX  );
		n_win_scroller_proc( hwnd, msg, wparam, lparam, H_SCR_EDGE );
		n_win_scroller_proc( hwnd, msg, wparam, lparam, H_SCR_AIR  );
		n_win_scroller_proc( hwnd, msg, wparam, lparam, H_SCR_ZOOM );

		nwclr_proc( hwnd, msg, wparam, lparam, &cp );
	}

	n_win_iconbutton_proc( hwnd, msg, wparam, lparam, H_BTN_00_00 );
	n_win_iconbutton_proc( hwnd, msg, wparam, lparam, H_BTN_01_00 );
	n_win_iconbutton_proc( hwnd, msg, wparam, lparam, H_BTN_02_00 );
	n_win_iconbutton_proc( hwnd, msg, wparam, lparam, H_BTN_03_00 );
	n_win_iconbutton_proc( hwnd, msg, wparam, lparam, H_BTN_04_00 );

	n_win_iconbutton_proc( hwnd, msg, wparam, lparam, H_BTN_00_01 );
	n_win_iconbutton_proc( hwnd, msg, wparam, lparam, H_BTN_01_01 );
	n_win_iconbutton_proc( hwnd, msg, wparam, lparam, H_BTN_02_01 );
	n_win_iconbutton_proc( hwnd, msg, wparam, lparam, H_BTN_03_01 );
	n_win_iconbutton_proc( hwnd, msg, wparam, lparam, H_BTN_04_01 );

	n_win_iconbutton_proc( hwnd, msg, wparam, lparam, H_BTN_00_02 );
	n_win_iconbutton_proc( hwnd, msg, wparam, lparam, H_BTN_01_02 );
	n_win_iconbutton_proc( hwnd, msg, wparam, lparam, H_BTN_02_02 );
	n_win_iconbutton_proc( hwnd, msg, wparam, lparam, H_BTN_03_02 );
	n_win_iconbutton_proc( hwnd, msg, wparam, lparam, H_BTN_04_02 );


	n_paint_tool_grabber_proc( hwnd, msg, wparam, lparam );


	n_win_simplemenu_proc( hwnd, msg, &wparam, &lparam, NULL );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

void
n_paint_tool_input_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	switch( msg ) {


	case WM_MOUSEWHEEL :
	{
//n_posix_debug_literal( "" );
		int delta = n_win_scrollbar_wheeldelta( wparam, 1 ,false );
		n_paint_tool_scrollbar_updown( H_SCR_ZOOM, delta * -1 );

	}
	break;


	case WM_KEYDOWN :

		if ( false == IsWindowEnabled( hwnd ) ) { break; }

		if ( n_win_simplemenu_target != NULL ) { break; }

/*
		if ( wparam == VK_ESCAPE )
		{
			n_win_hwndprintf_literal( hwnd_main, "%d %d", tooltype, grabber );
		}
*/

		if ( wparam == VK_F12 )
		{
			n_paint_printer( hwnd_main );
			break;
		}


		if ( n_win_is_hovered( hwnd_layr ) )
		{

			if ( n_win_is_input( VK_CONTROL ) )
			{

				if ( n_win_is_input( VK_UP ) )
				{
					int y = n_paint_layer_txtbox.select_cch_y;
					n_paint_layer_swap_up( y );
				} else
				if ( n_win_is_input( VK_DOWN ) )
				{
					int y = n_paint_layer_txtbox.select_cch_y;
					n_paint_layer_swap_down( y );
				}// else

			} else {

				if ( n_win_is_input( VK_UP ) )
				{
					int y = n_paint_layer_txtbox.select_cch_y;
					n_paint_layer_selection_move_up( y );
				} else
				if ( n_win_is_input( VK_DOWN ) )
				{
					int y = n_paint_layer_txtbox.select_cch_y;
					n_paint_layer_selection_move_down( y );
				} else
				if ( n_win_is_input( VK_RETURN ) )
				{
					n_paint_layer_rename_target = n_paint_layer_txtbox.select_cch_y;
					n_paint_layer_rename_go();
				}// else

			}

			break;
		}


		if ( n_win_is_input( VK_CONTROL ) )
		{

			if ( ( wparam == VK_UP )||( wparam == VK_DOWN )||( wparam == VK_LEFT )||( wparam == VK_RIGHT ) )
			{

				if ( tooltype == N_PAINT_TOOL_TYPE_GRAB )
				{
					if ( N_PAINT_GRABBER_IS_DRAG_OK() )
					{
						n_paint_grabber_proc( hwnd_main, WM_LBUTTONDOWN, 0,0, true );
					}
				}

			} else
			if ( wparam == 'A' )
			{

				if ( tooltype == N_PAINT_TOOL_TYPE_GRAB )
				{
					if ( N_PAINT_GRABBER_IS_NEUTRAL() )
					{
						n_paint_grabber_select_all();
					}
				}

			} else
			if ( wparam == 'C' )
			{

				if ( tooltype == N_PAINT_TOOL_TYPE_GRAB )
				{
					if ( N_PAINT_GRABBER_IS_DRAG_OK() )
					{
						n_paint_grabber_copy();
					}
				}

			} else
			if ( wparam == 'V' )
			{

				if ( tooltype == N_PAINT_TOOL_TYPE_GRAB )
				{
					if ( N_PAINT_GRABBER_IS_DRAG_OK() )
					{
						n_paint_grabber_paste();
					}
				}

			} //else



			break;
		}


		if ( n_win_is_input( VK_SHIFT ) )
		{

			if ( tooltype == N_PAINT_TOOL_TYPE_PEN )
			{
				n_paint_pen_key2cursor();
			}

			break;
		}


		// [!] : alt key

		if ( n_win_is_input( VK_MENU ) )
		{

			break;
		}


		if ( N_PAINT_GRABBER_IS_DRAG_OK() )
		{

			if ( wparam == VK_INSERT )
			{

				n_paint_grabber_paste();

			} else
			if ( ( wparam == VK_UP )||( wparam == VK_DOWN )||( wparam == VK_LEFT )||( wparam == VK_RIGHT ) )
			{

				if ( tooltype == N_PAINT_TOOL_TYPE_GRAB )
				{

					const s32 step = 1;

					s32 x,y; n_paint_grabber_system_get( &x,&y, NULL,NULL, NULL,NULL );

					if ( n_win_is_input( VK_UP    ) ) { y -= step; }
					if ( n_win_is_input( VK_DOWN  ) ) { y += step; }
					if ( n_win_is_input( VK_LEFT  ) ) { x -= step; }
					if ( n_win_is_input( VK_RIGHT ) ) { x += step; }

					n_paint_grabber_system_set( &x,&y, NULL,NULL, NULL,NULL );
					n_paint_grabber_status();

					n_paint_grabber_resync_auto();

					if ( n_paint_thumbnail_is_on() ) { n_paint_refresh_client(); }

				}

			}

		} else
		if ( ( N_PAINT_GRABBER_IS_STRETCH_PROPORTIONAL() )||( N_PAINT_GRABBER_IS_STRETCH_TRANSFORM() ) )
		{

			if ( ( wparam == VK_UP )||( wparam == VK_DOWN )||( wparam == VK_LEFT )||( wparam == VK_RIGHT ) )
			{

				if ( hwnd_main != n_win_cursor2hwnd() ) { break; }


				const s32 step = 1;

				POINT p; GetCursorPos( &p );

				if ( n_win_is_input( VK_UP    ) ) { p.y -= step; }
				if ( n_win_is_input( VK_DOWN  ) ) { p.y += step; }
				if ( n_win_is_input( VK_LEFT  ) ) { p.x -= step; }
				if ( n_win_is_input( VK_RIGHT ) ) { p.x += step; }

				SetCursorPos( p.x, p.y );

			}

		}


		if ( tooltype != N_PAINT_TOOL_TYPE_GRAB )
		{

			const s32 step = 1;

			s32 delta_x = 0;
			s32 delta_y = 0;

			if ( n_win_is_input( VK_UP    ) ) { delta_y += step; }
			if ( n_win_is_input( VK_DOWN  ) ) { delta_y -= step; }
			if ( n_win_is_input( VK_LEFT  ) ) { delta_x += step; }
			if ( n_win_is_input( VK_RIGHT ) ) { delta_x -= step; }

			//if ( delta_x != 0 ) { n_win_scroll_position_updown( hwnd_main, SB_HORZ, delta_x ); }
			//if ( delta_y != 0 ) { n_win_scroll_position_updown( hwnd_main, SB_VERT, delta_y ); }

		}


		// [!] : don't use wparam : combinaiton with scrolling

		//if ( wparam == VK_RETURN )
		if ( n_win_is_input( VK_RETURN ) )
		{

			// [!] : useless
			//mouse_event( MOUSEEVENTF_LEFTDOWN, 0,0, 0, 0 );
			//mouse_event( MOUSEEVENTF_LEFTUP,   0,0, 0, 0 );

			if ( tooltype == N_PAINT_TOOL_TYPE_GRAB )
			{
				//
			} else {
				n_paint_pen_on_lbuttondown( hwnd_main );
				//n_win_message_send( hwnd_main, WM_LBUTTONDOWN, 0,0 );
			}

		}


		if ( wparam == VK_DELETE ) { wparam = N_PAINT_KEY_5; }


		if ( wparam == N_PAINT_KEY_A ) { n_win_message_send( hwnd_tool, WM_COMMAND, 0, H_BTN_00_00 ); }
		if ( wparam == N_PAINT_KEY_B ) { n_win_message_send( hwnd_tool, WM_COMMAND, 0, H_BTN_01_00 ); }
		if ( wparam == N_PAINT_KEY_C ) { n_win_message_send( hwnd_tool, WM_COMMAND, 0, H_BTN_02_00 ); }
		if ( wparam == N_PAINT_KEY_D ) { n_win_message_send( hwnd_tool, WM_COMMAND, 0, H_BTN_03_00 ); }
		if ( wparam == N_PAINT_KEY_E ) { n_win_message_send( hwnd_tool, WM_COMMAND, 0, H_BTN_04_00 ); }

		if ( wparam == 'F' )
		{
			n_paint_tool_iconbutton_pentype( N_PAINT_TOOL_TYPE_PEN );
		}
		if ( wparam == 'G' )
		{
			n_paint_tool_iconbutton_pentype( N_PAINT_TOOL_TYPE_FILL );
		}
		if ( wparam == 'H' )
		{
			if ( tooltype == N_PAINT_TOOL_TYPE_GRAB ) { n_paint_grabber_reset(); }
			n_paint_tool_iconbutton_pentype( N_PAINT_TOOL_TYPE_GRAB );
		}
		if ( wparam == 'I' )
		{
			//
		}
		if ( wparam == N_PAINT_KEY_J )
		{
			n_win_gui( hwnd_main, WINDOW, n_paint_colorhistory_wndproc, &n_paint_hpopup );
		}

		if ( wparam == 'K' ) { n_paint_tool_filter( N_PAINT_FILTER_SCALE_LIL ); }
		if ( wparam == 'L' ) { n_paint_tool_filter( N_PAINT_FILTER_SCALE_BIG ); }
		if ( wparam == 'M' ) { n_paint_tool_filter( N_PAINT_FILTER_MIRROR    ); }
		if ( wparam == 'N' ) { n_paint_tool_filter( N_PAINT_FILTER_ROTATE_L  ); }
		if ( wparam == 'O' ) { n_paint_tool_filter( N_PAINT_FILTER_ROTATE_R  ); }

		if ( wparam == 'P' ) { n_paint_tool_scrollbar_updown( H_SCR_SIZE, -1 ); }
		if ( wparam == 'Q' ) { n_paint_tool_scrollbar_updown( H_SCR_SIZE,  1 ); }
		if ( wparam == 'R' ) { n_paint_tool_scrollbar_updown( H_SCR_MIX , -1 ); }
		if ( wparam == 'S' ) { n_paint_tool_scrollbar_updown( H_SCR_MIX ,  1 ); }
		if ( wparam == 'T' ) { n_paint_tool_scrollbar_updown( H_SCR_EDGE, -1 ); }

		if ( wparam == 'U' ) { n_paint_tool_scrollbar_updown( H_SCR_EDGE,  1 ); }
		if ( wparam == 'V' ) { n_paint_tool_scrollbar_updown( H_SCR_AIR , -1 ); }
		if ( wparam == 'W' ) { n_paint_tool_scrollbar_updown( H_SCR_AIR ,  1 ); }
		if ( wparam == 'X' ) { n_paint_tool_scrollbar_updown( H_SCR_ZOOM, -1 ); }
		if ( wparam == 'Y' ) { n_paint_tool_scrollbar_updown( H_SCR_ZOOM,  1 ); }

		if ( wparam == 'Z' )
		{
			if ( n_win_is_hovered( hwnd_main ) )
			{
				if ( n_paint_hamburger_is_hovered == false )
				{
					n_win_cursor_add_literal( NULL, "NONNON_PAINT_ERASER" );
					n_win_cursor_add_literal( hwnd, "NONNON_PAINT_ERASER" );
				}

				nwclr_enable( &cp, false );

				n_paint_quick_eraser = true;
			}
		}

		if ( wparam == N_PAINT_KEY_1 ) { n_paint_menu_main( N_PAINT_MENU_PREVIEW   , true ); }
		if ( wparam == N_PAINT_KEY_2 ) { n_paint_menu_main( N_PAINT_MENU_GRID      , true ); }
		if ( wparam == N_PAINT_KEY_3 ) { n_paint_menu_main( N_PAINT_MENU_PIXELGRID , true ); }
		if ( wparam == N_PAINT_KEY_4 ) { n_paint_menu_main( N_PAINT_MENU_THUMBNAIL , true ); }
		if ( wparam == N_PAINT_KEY_5 ) { n_paint_menu_main( N_PAINT_MENU_GRAYCANVAS, true ); }
		if ( wparam == N_PAINT_KEY_6 ) { n_paint_menu_main( N_PAINT_MENU_CLR_CANVAS, true ); }
		if ( wparam == N_PAINT_KEY_7 ) { n_paint_menu_main( N_PAINT_MENU_ALPHA     , true ); }
		if ( wparam == N_PAINT_KEY_8 ) { n_paint_menu_main( N_PAINT_MENU_REPLACER  , true ); }
		if ( wparam == N_PAINT_KEY_9 ) { n_paint_menu_main( N_PAINT_MENU_INI2GDI   , true ); }
		if ( wparam == N_PAINT_KEY_0 ) { n_paint_menu_main( N_PAINT_MENU_PROPERTY  , true ); }

	break;

	case WM_KEYUP :
//n_win_hwndprintf_literal( hwnd_main, "%d", wparam );

		if ( wparam == 'Z' )
		{
			n_paint_pen_cursor_default(      NULL );
			n_paint_pen_cursor_default( hwnd_main );

			nwclr_enable( &cp, true );

			n_paint_quick_eraser = false;
		}

		if ( wparam == VK_RETURN )
		{

			if ( tooltype == N_PAINT_TOOL_TYPE_GRAB )
			{
				//
			} else {
				n_paint_pen_on_lbuttonup( hwnd_main );
				//n_win_message_send( hwnd_main, WM_LBUTTONUP, 0,0 );
			}

		}

	break;


	} // switch


	return;
}


#undef H_BTN_00_00
#undef H_BTN_01_00
#undef H_BTN_02_00
#undef H_BTN_03_00
#undef H_BTN_04_00

#undef H_BTN_00_01
#undef H_BTN_01_01
#undef H_BTN_02_01
#undef H_BTN_03_01
#undef H_BTN_04_01

#undef H_BTN_00_02
#undef H_BTN_01_02
#undef H_BTN_02_02
#undef H_BTN_03_02
#undef H_BTN_04_02


#undef H_SCR_SIZE
#undef H_SCR_MIX
#undef H_SCR_EDGE
#undef H_SCR_AIR
#undef H_SCR_ZOOM

